// ---------------------------------------------------------------------------
// Data access layer.
//
// Right now these functions return SAMPLE data so the site renders immediately.
// Each is marked with TODO(backend) — replace the body with a real Supabase
// query and the rest of the app keeps working unchanged.
// ---------------------------------------------------------------------------
import geo from "@/data/geo.json";
import cities from "@/data/cities.json";
import popular from "@/data/popular.json";
import popularEnglish from "@/data/popular_english.json";

export type Country = { name: string; code: string; flag: string };
export type USState = { name: string; code: string };

export const COUNTRIES: Country[] = geo.countries;
export const US_STATES: USState[] = geo.usStates;
export const US_CITIES: Record<string, string[]> = (cities as any).usCities;
export const COUNTRY_CITIES: Record<string, string[]> = (cities as any).countryCities;
export const POPULAR_ENGLISH: string[] = popularEnglish as string[];
export const POPULAR_STATES: string[] = (popular as any).states;
export const POPULAR_CITIES: Record<string, string[]> = (popular as any).cities;

export const CATEGORIES = [
  { id: "home", label: "Home & Repair", icon: "🏠" },
  { id: "auto", label: "Automotive", icon: "🚗" },
  { id: "professional", label: "Professional Services", icon: "💼" },
  { id: "legal", label: "Legal & Financial", icon: "⚖️" },
  { id: "creative", label: "Creative & Design", icon: "🎨" },
  { id: "tech", label: "Tech & AI", icon: "🤖" },
  { id: "marketing", label: "Marketing & Media", icon: "📣" },
  { id: "wellness", label: "Health & Wellness", icon: "🩺" },
  { id: "beauty", label: "Beauty & Personal Care", icon: "💇" },
  { id: "food", label: "Food & Catering", icon: "🍽️" },
  { id: "events", label: "Events & Entertainment", icon: "🎉" },
  { id: "education", label: "Education & Tutoring", icon: "📚" },
  { id: "realestate", label: "Real Estate", icon: "🔑" },
  { id: "retail", label: "Retail & Shopping", icon: "🛍️" },
  { id: "pets", label: "Pets & Animals", icon: "🐾" },
  { id: "trades", label: "Skilled Trades", icon: "🔧" },
];

// slugify for URL segments: "New York City" -> "new-york-city"
export const slug = (s: string) =>
  s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

// ---- Stable sample listings so pages render before the DB is wired up ----
export type Listing = {
  id: string; name: string; slug: string; category: string;
  rating: number; reviews: number; verified: boolean; tier: "free" | "pro" | "featured";
  tagline: string;
};

function seeded(placeKey: string): Listing[] {
  let seed = 0;
  for (let i = 0; i < placeKey.length; i++) seed = (seed * 31 + placeKey.charCodeAt(i)) >>> 0;
  const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  const NAMES = ["Summit","Ironwood","Blue Harbor","Copper","North Star","Evergreen","Redline","Meridian","Willow","Anchor","Bright","Vantage","Cobalt","Granite","Silverleaf","Harbor","Pinnacle","Cedar","Atlas","Kingfisher"];
  const SUFFIX = ["Group","Co.","Services","& Sons","Studio","Works","Collective","Partners","LLC","Labs"];
  const count = 4 + Math.floor(rnd() * 6);
  const out: Listing[] = [];
  for (let i = 0; i < count; i++) {
    const cat = CATEGORIES[Math.floor(rnd() * CATEGORIES.length)];
    const name = `${NAMES[Math.floor(rnd()*NAMES.length)]} ${SUFFIX[Math.floor(rnd()*SUFFIX.length)]}`;
    const t = rnd();
    out.push({
      id: `${placeKey}-${i}`, name, slug: slug(name), category: cat.id,
      rating: Math.round((3.6 + rnd() * 1.4) * 10) / 10,
      reviews: 5 + Math.floor(rnd() * 400),
      verified: rnd() > 0.5,
      tier: t > 0.85 ? "featured" : t > 0.6 ? "pro" : "free",
      tagline: `Trusted ${cat.label.toLowerCase()} serving the local area.`,
    });
  }
  return out;
}

// TODO(backend): replace with:  select * from listings where city_key = $1
export async function getListings(cityKey: string): Promise<Listing[]> {
  return seeded(cityKey);
}

// TODO(backend): replace with a single-row select joined to gallery/reviews/etc.
export async function getBusiness(cityKey: string, businessSlug: string) {
  const list = seeded(cityKey);
  const found = list.find((l) => l.slug === businessSlug) ?? list[0];
  return found ?? null;
}

export function cityKeyUS(stateCode: string, city: string) { return `US-${stateCode}-${city}`; }
export function cityKeyIntl(countryCode: string, city: string) { return `${countryCode}-${city}`; }
