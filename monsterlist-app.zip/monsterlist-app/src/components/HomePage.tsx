"use client";
import React from "react";
import {
  Search, MapPin, Star, Check, Plus, ChevronRight, BadgeCheck, Crown,
  Sparkles, TrendingUp, FileText, PlayCircle, ArrowRight, Globe2,
  Facebook, Instagram, Youtube, Heart, MessageCircle
} from "lucide-react";

// ---------------------------------------------------------------------------
// Sample data — replace with server-fetched records in production.
// ---------------------------------------------------------------------------
const TOP_CATEGORIES = [
  { icon: "🏠", label: "Home & Repair", count: "84,210" },
  { icon: "🔧", label: "Skilled Trades", count: "61,540" },
  { icon: "💼", label: "Professional Services", count: "52,880" },
  { icon: "🤖", label: "Tech & AI", count: "38,120" },
  { icon: "🩺", label: "Health & Wellness", count: "44,670" },
  { icon: "🎨", label: "Creative & Design", count: "29,340" },
  { icon: "🍽️", label: "Food & Catering", count: "47,900" },
  { icon: "🚗", label: "Automotive", count: "35,610" },
  { icon: "⚖️", label: "Legal & Financial", count: "22,150" },
  { icon: "💇", label: "Beauty & Personal Care", count: "40,020" },
  { icon: "🎉", label: "Events & Entertainment", count: "18,760" },
  { icon: "🔑", label: "Real Estate", count: "26,430" },
];

const TOP_LOCATIONS = [
  { city: "New York City", region: "New York", count: "112,400", hue: 210 },
  { city: "Los Angeles", region: "California", count: "98,760", hue: 30 },
  { city: "Chicago", region: "Illinois", count: "71,220", hue: 190 },
  { city: "Houston", region: "Texas", count: "64,880", hue: 10 },
  { city: "Phoenix", region: "Arizona", count: "51,340", hue: 45 },
  { city: "London", region: "United Kingdom", count: "88,910", hue: 260 },
  { city: "Toronto", region: "Canada", count: "57,600", hue: 200 },
  { city: "Sydney", region: "Australia", count: "43,270", hue: 170 },
];

const PREMIUM_MEMBERS = [
  { name: "Summit Roofing Co.", category: "Roofing", city: "Phoenix, AZ", rating: 4.8, reviews: 214, hue: 205 },
  { name: "North Star Studio", category: "Creative & Design", city: "Denver, CO", rating: 4.9, reviews: 132, hue: 265 },
  { name: "Meridian Legal", category: "Legal & Financial", city: "Austin, TX", rating: 5.0, reviews: 88, hue: 152 },
  { name: "Loop Automations", category: "Tech & AI", city: "Remote", rating: 4.7, reviews: 96, hue: 30 },
];

const NEW_MEMBERS = [
  { name: "Cobalt Electric", category: "Skilled Trades", city: "Seattle, WA", hue: 200 },
  { name: "Willow & Vine", category: "Health & Wellness", city: "Portland, OR", hue: 145 },
  { name: "Amber Table", category: "Food & Catering", city: "Nashville, TN", hue: 40 },
  { name: "Granite Fitness", category: "Health & Wellness", city: "Boston, MA", hue: 340 },
  { name: "Cedar & Co.", category: "Home & Repair", city: "Charlotte, NC", hue: 100 },
  { name: "Kingfisher Media", category: "Marketing & Media", city: "Miami, FL", hue: 220 },
];

const CONTENT_PROMOS = [
  { type: "Article", title: "5 Signs Your Roof Needs Replacing Before Storm Season", by: "Summit Roofing Co.", meta: "4 min read", hue: 205, icon: "article" },
  { type: "Video", title: "Full Kitchen Remodel — Start to Finish Timelapse", by: "Cedar & Co.", meta: "8:42", hue: 30, icon: "video" },
  { type: "Article", title: "How to Choose an Accountant for Your Small Business", by: "Meridian Legal", meta: "6 min read", hue: 152, icon: "article" },
];

const SOCIAL_PROMOS = [
  { platform: "instagram", handle: "@summitroofingaz", text: "Fresh tile install in Scottsdale ☀️", likes: 342, comments: 18, hue: 205 },
  { platform: "tiktok", handle: "@northstarstudio", text: "Brand reveal for a local coffee roaster ☕", likes: 12400, comments: 210, hue: 300 },
  { platform: "youtube", handle: "Cedar & Co.", text: "New video: full kitchen remodel tour", likes: 891, comments: 64, hue: 30 },
  { platform: "facebook", handle: "Amber Table Catering", text: "Now booking summer weddings — DM us!", likes: 156, comments: 42, hue: 220 },
];

const STATS = [
  { value: "1.2M+", label: "Businesses listed" },
  { value: "249", label: "Countries" },
  { value: "18M+", label: "Monthly searches" },
  { value: "4.6★", label: "Avg. rating" },
];

const PLATFORMS = {
  facebook: { label: "Facebook", color: "#1877f2", Icon: Facebook },
  instagram: { label: "Instagram", color: "#e1306c", Icon: Instagram },
  tiktok: { label: "TikTok", color: "#010101", Icon: TikTokIcon },
  youtube: { label: "YouTube", color: "#ff0000", Icon: Youtube },
};

const imgBg = (hue) => ({ background: `linear-gradient(135deg, hsl(${hue} 60% 62%), hsl(${hue} 55% 48%))` });
const fmt = (n) => (n >= 1000 ? (n / 1000).toFixed(n >= 10000 ? 0 : 1) + "K" : n);

export default function HomePage() {
  return (
    <div className="hp">
      <HPStyle />

      {/* Nav */}
      <header className="hp-nav">
        <div className="hp-container hp-nav-inner">
          <a href="#" className="hp-logo">Monster<span>List</span></a>
          <nav className="hp-nav-links">
            <a href="#categories">Categories</a>
            <a href="#locations">Locations</a>
            <a href="#premium">Premium</a>
          </nav>
          <div className="hp-nav-cta">
            <a href="#" className="hp-link">Sign in</a>
            <button className="hp-btn-primary"><Plus size={16} /> Add a business</button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="hp-hero">
        <div className="hp-container">
          <span className="hp-hero-pill"><Sparkles size={14} /> The worldwide small-business directory</span>
          <h1 className="hp-hero-title">Find & get found by<br />trusted local businesses.</h1>
          <p className="hp-hero-sub">Browse 1.2M+ businesses across 249 countries — with reviews, photos, content, and social feeds all in one place.</p>
          <div className="hp-hero-search">
            <div className="hp-search-field">
              <Search size={19} style={{ color: "var(--faint)" }} />
              <input placeholder="What are you looking for?" />
            </div>
            <div className="hp-search-divider" />
            <div className="hp-search-field">
              <MapPin size={19} style={{ color: "var(--faint)" }} />
              <input placeholder="City, state, or country" />
            </div>
            <button className="hp-btn-primary hp-search-btn">Search</button>
          </div>
          <div className="hp-hero-tags">
            <span>Popular:</span>
            <a href="#">Roofers</a><a href="#">Plumbers</a><a href="#">Web Design</a><a href="#">Caterers</a><a href="#">Accountants</a>
          </div>
        </div>
        <div className="hp-hero-stats">
          <div className="hp-container hp-stats-row">
            {STATS.map((s) => (
              <div key={s.label} className="hp-stat">
                <span className="hp-stat-value">{s.value}</span>
                <span className="hp-stat-label">{s.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="hp-container">
        {/* Top Categories */}
        <Section id="categories" icon={<TrendingUp size={18} />} title="Top categories" sub="The most-searched business types on MonsterList" cta="Browse all categories">
          <div className="hp-cat-grid">
            {TOP_CATEGORIES.map((c) => (
              <a key={c.label} href="#" className="hp-cat">
                <span className="hp-cat-icon">{c.icon}</span>
                <span className="hp-cat-body">
                  <strong>{c.label}</strong>
                  <span className="hp-cat-count">{c.count} listings</span>
                </span>
                <ChevronRight size={16} className="hp-cat-arrow" />
              </a>
            ))}
          </div>
        </Section>

        {/* Premium Members */}
        <Section id="premium" icon={<Crown size={18} />} title="Featured premium members" sub="Verified businesses with full storefronts" cta="See all premium">
          <div className="hp-premium-grid">
            {PREMIUM_MEMBERS.map((m) => (
              <a key={m.name} href="#" className="hp-premium">
                <div className="hp-premium-cover" style={imgBg(m.hue)}>
                  <span className="hp-premium-badge"><Crown size={12} /> Premium</span>
                </div>
                <div className="hp-premium-body">
                  <div className="hp-premium-logo" style={imgBg(m.hue)}>{m.name.charAt(0)}</div>
                  <div className="hp-premium-info">
                    <div className="hp-premium-name">
                      {m.name} <BadgeCheck size={15} style={{ color: "var(--green)" }} />
                    </div>
                    <span className="hp-premium-cat">{m.category}</span>
                    <div className="hp-premium-meta">
                      <span className="hp-star"><Star size={13} fill="var(--star)" strokeWidth={0} style={{ color: "var(--star)" }} /> {m.rating}</span>
                      <span className="hp-muted">({m.reviews})</span>
                      <span className="hp-muted">· {m.city}</span>
                    </div>
                  </div>
                </div>
              </a>
            ))}
          </div>
        </Section>

        {/* New Members */}
        <Section icon={<Sparkles size={18} />} title="New members" sub="Businesses that just joined the directory" cta="Browse new listings">
          <div className="hp-new-grid">
            {NEW_MEMBERS.map((m) => (
              <a key={m.name} href="#" className="hp-new">
                <div className="hp-new-logo" style={imgBg(m.hue)}>{m.name.charAt(0)}</div>
                <div className="hp-new-info">
                  <strong>{m.name}</strong>
                  <span className="hp-muted">{m.category}</span>
                  <span className="hp-new-city"><MapPin size={12} /> {m.city}</span>
                </div>
                <span className="hp-new-badge">New</span>
              </a>
            ))}
          </div>
        </Section>

        {/* Top Locations */}
        <Section id="locations" icon={<Globe2 size={18} />} title="Top locations" sub="Cities with the most active listings" cta="Browse all locations">
          <div className="hp-loc-grid">
            {TOP_LOCATIONS.map((l) => (
              <a key={l.city} href="#" className="hp-loc" style={imgBg(l.hue)}>
                <div className="hp-loc-overlay">
                  <strong>{l.city}</strong>
                  <span>{l.region}</span>
                  <span className="hp-loc-count">{l.count} listings</span>
                </div>
              </a>
            ))}
          </div>
        </Section>

        {/* Content Promotions */}
        <Section icon={<FileText size={18} />} title="Featured content" sub="Articles & videos from businesses on MonsterList" cta="Explore content">
          <div className="hp-content-grid">
            {CONTENT_PROMOS.map((c) => (
              <a key={c.title} href="#" className="hp-content">
                <div className="hp-content-media" style={imgBg(c.hue)}>
                  {c.icon === "video" ? <PlayCircle size={40} className="hp-content-play" /> : null}
                  <span className="hp-content-type">{c.icon === "video" ? <PlayCircle size={12} /> : <FileText size={12} />} {c.type}</span>
                  {c.icon === "video" && <span className="hp-content-dur">{c.meta}</span>}
                </div>
                <div className="hp-content-body">
                  <h4>{c.title}</h4>
                  <div className="hp-content-meta">
                    <span>By {c.by}</span>
                    {c.icon === "article" && <span className="hp-muted">· {c.meta}</span>}
                  </div>
                </div>
              </a>
            ))}
          </div>
        </Section>

        {/* Social Media Promotions */}
        <Section icon={<Instagram size={18} />} title="Trending on social" sub="Promoted posts from businesses across platforms" cta="See social feed">
          <div className="hp-social-grid">
            {SOCIAL_PROMOS.map((p, i) => {
              const plat = PLATFORMS[p.platform];
              return (
                <a key={i} href="#" className="hp-social">
                  <div className="hp-social-media" style={imgBg(p.hue)}>
                    <span className="hp-social-plat" style={{ background: plat.color }}><plat.Icon size={13} /></span>
                  </div>
                  <div className="hp-social-body">
                    <strong>{p.handle}</strong>
                    <p>{p.text}</p>
                    <div className="hp-social-stats">
                      <span><Heart size={12} /> {fmt(p.likes)}</span>
                      <span><MessageCircle size={12} /> {fmt(p.comments)}</span>
                    </div>
                  </div>
                </a>
              );
            })}
          </div>
        </Section>

        {/* CTA band */}
        <section className="hp-cta-band">
          <div className="hp-cta-content">
            <h2>Own a business? Get listed free.</h2>
            <p>Create your profile, add photos and content, and start showing up in searches and AI results today.</p>
          </div>
          <div className="hp-cta-actions">
            <button className="hp-btn-light"><Plus size={17} /> Add your business</button>
            <button className="hp-btn-outline-light">See premium plans <ArrowRight size={16} /></button>
          </div>
        </section>
      </div>

      {/* Footer */}
      <footer className="hp-footer">
        <div className="hp-container hp-footer-inner">
          <div className="hp-footer-brand">
            <span className="hp-logo" style={{ fontSize: 18 }}>Monster<span>List</span></span>
            <p>A small-business directory open to the world.</p>
          </div>
          <div className="hp-footer-cols">
            <div><h5>Discover</h5><a href="#">Categories</a><a href="#">Locations</a><a href="#">Premium members</a><a href="#">New listings</a></div>
            <div><h5>For business</h5><a href="#">Add a business</a><a href="#">Premium plans</a><a href="#">Claim a listing</a><a href="#">Advertise</a></div>
            <div><h5>Company</h5><a href="#">About</a><a href="#">Contact</a><a href="#">Privacy</a><a href="#">Terms</a></div>
          </div>
        </div>
        <div className="hp-container hp-footer-bottom">© 2026 MonsterList · monsterlist.org</div>
      </footer>
    </div>
  );
}

function Section({ id, icon, title, sub, cta, children }) {
  return (
    <section id={id} className="hp-section">
      <div className="hp-section-head">
        <div>
          <h2 className="hp-section-title">{icon} {title}</h2>
          {sub && <p className="hp-section-sub">{sub}</p>}
        </div>
        {cta && <a href="#" className="hp-section-cta">{cta} <ArrowRight size={15} /></a>}
      </div>
      {children}
    </section>
  );
}

function TikTokIcon({ size = 16 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor"><path d="M16.6 5.82a4.28 4.28 0 0 1-1-.06 4.28 4.28 0 0 1-2.9-2.31A4.24 4.24 0 0 1 12.4 2h-3.1v13.4a2.6 2.6 0 0 1-2.6 2.5 2.6 2.6 0 1 1 .74-5.09V9.66a5.7 5.7 0 0 0-.74-.05A5.68 5.68 0 1 0 12.4 15.3V8.6a7.3 7.3 0 0 0 4.2 1.34V6.8a4.28 4.28 0 0 1-.2-.98z" /></svg>;
}

function HPStyle() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
      .hp{
        --bg:#f6f7f9;--card:#ffffff;--ink:#1a1d24;--mute:#5b6270;--faint:#9aa1ad;
        --border:#e7e9ee;--border2:#eef0f4;--accent:#2563eb;--accent-soft:#eef3ff;
        --star:#f5a623;--green:#0ca678;--green-soft:#e6f7f1;--gold:#d97706;--gold-soft:#fef3e2;
        --font:'Plus Jakarta Sans',system-ui,-apple-system,sans-serif;
        background:var(--bg);color:var(--ink);font-family:var(--font);min-height:100vh;-webkit-font-smoothing:antialiased;
      }
      .hp *{box-sizing:border-box}
      .hp a{text-decoration:none;color:inherit}
      .hp-container{max-width:1120px;margin:0 auto;padding:0 24px}
      .hp-muted{color:var(--faint)}

      /* Nav */
      .hp-nav{background:rgba(255,255,255,.9);backdrop-filter:blur(10px);border-bottom:1px solid var(--border);position:sticky;top:0;z-index:30}
      .hp-nav-inner{display:flex;align-items:center;gap:32px;height:66px}
      .hp-logo{font-weight:800;font-size:21px;letter-spacing:-.02em;color:var(--ink)}
      .hp-logo span{color:var(--accent)}
      .hp-nav-links{display:flex;gap:24px;flex:1}
      .hp-nav-links a{font-size:14px;font-weight:600;color:var(--mute)}
      .hp-nav-links a:hover{color:var(--ink)}
      .hp-nav-cta{display:flex;align-items:center;gap:16px}
      .hp-link{font-size:14px;font-weight:600;color:var(--mute)}
      .hp-link:hover{color:var(--ink)}
      @media(max-width:760px){.hp-nav-links{display:none}}

      .hp-btn-primary{display:inline-flex;align-items:center;justify-content:center;gap:7px;background:var(--accent);color:#fff;font-weight:700;font-size:14px;font-family:inherit;border:none;border-radius:11px;padding:11px 18px;cursor:pointer;transition:background .15s,transform .1s;white-space:nowrap}
      .hp-btn-primary:hover{background:#1d4fd8;transform:translateY(-1px)}

      /* Hero */
      .hp-hero{background:linear-gradient(180deg,#fff,var(--bg));border-bottom:1px solid var(--border);padding-top:64px;position:relative;overflow:hidden}
      .hp-hero-pill{display:inline-flex;align-items:center;gap:6px;background:var(--accent-soft);color:var(--accent);font-weight:700;font-size:13px;padding:7px 14px;border-radius:999px;margin-bottom:22px}
      .hp-hero-title{font-size:clamp(32px,5.5vw,54px);line-height:1.06;letter-spacing:-.03em;font-weight:800;margin:0}
      .hp-hero-sub{color:var(--mute);font-size:18px;line-height:1.55;margin:18px 0 0;max-width:560px}
      .hp-hero-search{display:flex;align-items:center;gap:8px;background:var(--card);border:1px solid var(--border);border-radius:16px;padding:8px;margin-top:30px;max-width:720px;box-shadow:0 8px 30px rgba(20,24,40,.08)}
      .hp-search-field{flex:1;display:flex;align-items:center;gap:10px;padding:6px 12px}
      .hp-search-field input{flex:1;border:none;outline:none;font-size:15px;font-family:inherit;color:var(--ink);background:none}
      .hp-search-field input::placeholder{color:var(--faint)}
      .hp-search-divider{width:1px;height:28px;background:var(--border)}
      .hp-search-btn{padding:13px 26px;border-radius:11px}
      .hp-hero-tags{display:flex;flex-wrap:wrap;align-items:center;gap:12px;margin-top:20px;font-size:13.5px;color:var(--faint)}
      .hp-hero-tags a{color:var(--accent);font-weight:600}
      .hp-hero-tags a:hover{text-decoration:underline}
      @media(max-width:620px){.hp-hero-search{flex-direction:column;align-items:stretch}.hp-search-divider{display:none}.hp-search-btn{width:100%}}

      .hp-hero-stats{margin-top:56px;border-top:1px solid var(--border);background:rgba(255,255,255,.5)}
      .hp-stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:20px;padding:26px 24px}
      .hp-stat{display:flex;flex-direction:column;gap:3px;align-items:center;text-align:center}
      .hp-stat-value{font-size:26px;font-weight:800;letter-spacing:-.02em}
      .hp-stat-label{font-size:13px;color:var(--mute);font-weight:500}
      @media(max-width:560px){.hp-stats-row{grid-template-columns:repeat(2,1fr);gap:24px}}

      /* Section */
      .hp-section{padding:48px 0 8px}
      .hp-section-head{display:flex;align-items:flex-end;justify-content:space-between;gap:16px;margin-bottom:24px;flex-wrap:wrap}
      .hp-section-title{display:flex;align-items:center;gap:9px;font-size:22px;font-weight:800;letter-spacing:-.02em;margin:0}
      .hp-section-title svg{color:var(--accent)}
      .hp-section-sub{color:var(--mute);font-size:14.5px;margin:6px 0 0}
      .hp-section-cta{display:inline-flex;align-items:center;gap:5px;color:var(--accent);font-weight:700;font-size:14px;white-space:nowrap}
      .hp-section-cta:hover{gap:8px}

      /* Categories */
      .hp-cat-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
      @media(max-width:860px){.hp-cat-grid{grid-template-columns:repeat(2,1fr)}}
      @media(max-width:460px){.hp-cat-grid{grid-template-columns:1fr}}
      .hp-cat{display:flex;align-items:center;gap:13px;background:var(--card);border:1px solid var(--border);border-radius:14px;padding:15px 16px;transition:border-color .15s,box-shadow .15s,transform .1s}
      .hp-cat:hover{border-color:var(--accent);box-shadow:0 6px 16px rgba(37,99,235,.1);transform:translateY(-2px)}
      .hp-cat-icon{font-size:26px;line-height:1;flex-shrink:0}
      .hp-cat-body{flex:1;display:flex;flex-direction:column;min-width:0}
      .hp-cat-body strong{font-size:14px;font-weight:700}
      .hp-cat-count{font-size:12.5px;color:var(--faint)}
      .hp-cat-arrow{color:var(--faint);flex-shrink:0}
      .hp-cat:hover .hp-cat-arrow{color:var(--accent)}

      /* Premium */
      .hp-premium-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px}
      @media(max-width:960px){.hp-premium-grid{grid-template-columns:repeat(2,1fr)}}
      @media(max-width:520px){.hp-premium-grid{grid-template-columns:1fr}}
      .hp-premium{background:var(--card);border:1px solid var(--border);border-radius:16px;overflow:hidden;transition:box-shadow .15s,transform .1s;box-shadow:0 1px 3px rgba(20,24,40,.04)}
      .hp-premium:hover{box-shadow:0 10px 26px rgba(20,24,40,.1);transform:translateY(-3px)}
      .hp-premium-cover{height:76px;position:relative}
      .hp-premium-badge{position:absolute;top:10px;right:10px;display:inline-flex;align-items:center;gap:4px;background:var(--gold-soft);color:var(--gold);font-size:11px;font-weight:800;padding:3px 9px;border-radius:999px}
      .hp-premium-body{padding:0 16px 16px;margin-top:-24px}
      .hp-premium-logo{width:52px;height:52px;border-radius:14px;color:#fff;font-weight:800;font-size:22px;display:grid;place-items:center;border:3px solid var(--card);margin-bottom:10px}
      .hp-premium-name{display:flex;align-items:center;gap:5px;font-size:15px;font-weight:700}
      .hp-premium-cat{font-size:12.5px;color:var(--accent);font-weight:600}
      .hp-premium-meta{display:flex;align-items:center;gap:6px;margin-top:8px;font-size:13px}
      .hp-star{display:inline-flex;align-items:center;gap:3px;font-weight:700}

      /* New members */
      .hp-new-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
      @media(max-width:760px){.hp-new-grid{grid-template-columns:repeat(2,1fr)}}
      @media(max-width:460px){.hp-new-grid{grid-template-columns:1fr}}
      .hp-new{display:flex;align-items:center;gap:13px;background:var(--card);border:1px solid var(--border);border-radius:14px;padding:14px 16px;transition:border-color .15s,box-shadow .15s;position:relative}
      .hp-new:hover{border-color:var(--accent);box-shadow:0 6px 16px rgba(37,99,235,.08)}
      .hp-new-logo{width:44px;height:44px;border-radius:12px;color:#fff;font-weight:800;font-size:18px;display:grid;place-items:center;flex-shrink:0}
      .hp-new-info{display:flex;flex-direction:column;gap:1px;min-width:0}
      .hp-new-info strong{font-size:14px;font-weight:700}
      .hp-new-info .hp-muted{font-size:12.5px}
      .hp-new-city{display:inline-flex;align-items:center;gap:4px;font-size:12px;color:var(--mute);margin-top:2px}
      .hp-new-badge{position:absolute;top:12px;right:12px;background:var(--green-soft);color:var(--green);font-size:10.5px;font-weight:800;padding:2px 8px;border-radius:999px;text-transform:uppercase;letter-spacing:.03em}

      /* Locations */
      .hp-loc-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
      @media(max-width:860px){.hp-loc-grid{grid-template-columns:repeat(2,1fr)}}
      @media(max-width:460px){.hp-loc-grid{grid-template-columns:1fr}}
      .hp-loc{aspect-ratio:4/3;border-radius:16px;position:relative;overflow:hidden;display:flex;align-items:flex-end;transition:transform .12s}
      .hp-loc:hover{transform:translateY(-3px)}
      .hp-loc-overlay{width:100%;padding:16px;background:linear-gradient(180deg,transparent,rgba(0,0,0,.55));color:#fff;display:flex;flex-direction:column;gap:1px}
      .hp-loc-overlay strong{font-size:17px;font-weight:800}
      .hp-loc-overlay span{font-size:12.5px;opacity:.92}
      .hp-loc-count{font-size:11.5px !important;font-weight:600;margin-top:4px;opacity:.85 !important}

      /* Content */
      .hp-content-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
      @media(max-width:760px){.hp-content-grid{grid-template-columns:1fr}}
      .hp-content{background:var(--card);border:1px solid var(--border);border-radius:16px;overflow:hidden;transition:box-shadow .15s,transform .1s;box-shadow:0 1px 3px rgba(20,24,40,.04)}
      .hp-content:hover{box-shadow:0 10px 26px rgba(20,24,40,.1);transform:translateY(-3px)}
      .hp-content-media{aspect-ratio:16/9;position:relative;display:grid;place-items:center}
      .hp-content-play{color:#fff;opacity:.95;filter:drop-shadow(0 2px 6px rgba(0,0,0,.3))}
      .hp-content-type{position:absolute;top:10px;left:10px;display:inline-flex;align-items:center;gap:4px;background:rgba(255,255,255,.95);color:var(--ink);font-size:11px;font-weight:700;padding:3px 8px;border-radius:6px}
      .hp-content-dur{position:absolute;bottom:10px;right:10px;background:rgba(0,0,0,.75);color:#fff;font-size:11px;font-weight:600;padding:2px 6px;border-radius:5px}
      .hp-content-body{padding:15px 16px}
      .hp-content-body h4{margin:0 0 8px;font-size:15px;font-weight:700;line-height:1.35}
      .hp-content-meta{font-size:12.5px;color:var(--mute);font-weight:600}

      /* Social */
      .hp-social-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
      @media(max-width:860px){.hp-social-grid{grid-template-columns:repeat(2,1fr)}}
      @media(max-width:460px){.hp-social-grid{grid-template-columns:1fr}}
      .hp-social{background:var(--card);border:1px solid var(--border);border-radius:16px;overflow:hidden;transition:box-shadow .15s,transform .1s;box-shadow:0 1px 3px rgba(20,24,40,.04)}
      .hp-social:hover{box-shadow:0 10px 26px rgba(20,24,40,.1);transform:translateY(-3px)}
      .hp-social-media{aspect-ratio:1;position:relative}
      .hp-social-plat{position:absolute;top:10px;left:10px;width:26px;height:26px;border-radius:7px;display:grid;place-items:center;color:#fff}
      .hp-social-body{padding:13px 14px}
      .hp-social-body strong{font-size:13px;font-weight:700}
      .hp-social-body p{margin:5px 0 10px;font-size:13px;color:var(--mute);line-height:1.45;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
      .hp-social-stats{display:flex;gap:14px;font-size:12px;color:var(--mute);font-weight:600}
      .hp-social-stats span{display:inline-flex;align-items:center;gap:4px}

      /* CTA band */
      .hp-cta-band{background:linear-gradient(135deg,var(--accent),#4f46e5);border-radius:22px;padding:40px;margin:56px 0 24px;display:flex;align-items:center;justify-content:space-between;gap:28px;flex-wrap:wrap;color:#fff}
      .hp-cta-content h2{font-size:26px;font-weight:800;letter-spacing:-.02em;margin:0}
      .hp-cta-content p{margin:8px 0 0;font-size:15px;opacity:.9;max-width:440px;line-height:1.5}
      .hp-cta-actions{display:flex;gap:12px;flex-wrap:wrap}
      .hp-btn-light{display:inline-flex;align-items:center;gap:7px;background:#fff;color:var(--accent);font-weight:700;font-size:14.5px;font-family:inherit;border:none;border-radius:12px;padding:13px 22px;cursor:pointer}
      .hp-btn-light:hover{background:#f0f4ff}
      .hp-btn-outline-light{display:inline-flex;align-items:center;gap:7px;background:rgba(255,255,255,.14);color:#fff;font-weight:700;font-size:14.5px;font-family:inherit;border:1px solid rgba(255,255,255,.3);border-radius:12px;padding:13px 22px;cursor:pointer}
      .hp-btn-outline-light:hover{background:rgba(255,255,255,.22)}

      /* Footer */
      .hp-footer{background:var(--card);border-top:1px solid var(--border);margin-top:40px;padding:48px 0 24px}
      .hp-footer-inner{display:flex;justify-content:space-between;gap:40px;flex-wrap:wrap;padding-bottom:32px;border-bottom:1px solid var(--border)}
      .hp-footer-brand p{color:var(--mute);font-size:14px;margin:12px 0 0;max-width:240px}
      .hp-footer-cols{display:flex;gap:56px;flex-wrap:wrap}
      .hp-footer-cols h5{font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:var(--ink);margin:0 0 14px}
      .hp-footer-cols a{display:block;font-size:14px;color:var(--mute);margin-bottom:10px}
      .hp-footer-cols a:hover{color:var(--accent)}
      .hp-footer-bottom{padding-top:22px;font-size:13px;color:var(--faint)}
    `}</style>
  );
}
