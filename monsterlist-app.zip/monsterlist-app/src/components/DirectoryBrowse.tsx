"use client";
import React, { useState, useMemo } from "react";
import { Search, MapPin, Star, Plus, X, Check, ChevronRight, ChevronLeft, Grid3x3, Globe2 } from "lucide-react";

// ==== Geographic + category data (generated) ====
const COUNTRIES = [{"name": "Afghanistan", "code": "AF", "flag": "🇦🇫"}, {"name": "Albania", "code": "AL", "flag": "🇦🇱"}, {"name": "Algeria", "code": "DZ", "flag": "🇩🇿"}, {"name": "American Samoa", "code": "AS", "flag": "🇦🇸"}, {"name": "Andorra", "code": "AD", "flag": "🇦🇩"}, {"name": "Angola", "code": "AO", "flag": "🇦🇴"}, {"name": "Anguilla", "code": "AI", "flag": "🇦🇮"}, {"name": "Antarctica", "code": "AQ", "flag": "🇦🇶"}, {"name": "Antigua and Barbuda", "code": "AG", "flag": "🇦🇬"}, {"name": "Argentina", "code": "AR", "flag": "🇦🇷"}, {"name": "Armenia", "code": "AM", "flag": "🇦🇲"}, {"name": "Aruba", "code": "AW", "flag": "🇦🇼"}, {"name": "Australia", "code": "AU", "flag": "🇦🇺"}, {"name": "Austria", "code": "AT", "flag": "🇦🇹"}, {"name": "Azerbaijan", "code": "AZ", "flag": "🇦🇿"}, {"name": "Bahamas", "code": "BS", "flag": "🇧🇸"}, {"name": "Bahrain", "code": "BH", "flag": "🇧🇭"}, {"name": "Bangladesh", "code": "BD", "flag": "🇧🇩"}, {"name": "Barbados", "code": "BB", "flag": "🇧🇧"}, {"name": "Belarus", "code": "BY", "flag": "🇧🇾"}, {"name": "Belgium", "code": "BE", "flag": "🇧🇪"}, {"name": "Belize", "code": "BZ", "flag": "🇧🇿"}, {"name": "Benin", "code": "BJ", "flag": "🇧🇯"}, {"name": "Bermuda", "code": "BM", "flag": "🇧🇲"}, {"name": "Bhutan", "code": "BT", "flag": "🇧🇹"}, {"name": "Bolivia, Plurinational State of", "code": "BO", "flag": "🇧🇴"}, {"name": "Bonaire, Sint Eustatius and Saba", "code": "BQ", "flag": "🇧🇶"}, {"name": "Bosnia and Herzegovina", "code": "BA", "flag": "🇧🇦"}, {"name": "Botswana", "code": "BW", "flag": "🇧🇼"}, {"name": "Bouvet Island", "code": "BV", "flag": "🇧🇻"}, {"name": "Brazil", "code": "BR", "flag": "🇧🇷"}, {"name": "British Indian Ocean Territory", "code": "IO", "flag": "🇮🇴"}, {"name": "Brunei Darussalam", "code": "BN", "flag": "🇧🇳"}, {"name": "Bulgaria", "code": "BG", "flag": "🇧🇬"}, {"name": "Burkina Faso", "code": "BF", "flag": "🇧🇫"}, {"name": "Burundi", "code": "BI", "flag": "🇧🇮"}, {"name": "Cabo Verde", "code": "CV", "flag": "🇨🇻"}, {"name": "Cambodia", "code": "KH", "flag": "🇰🇭"}, {"name": "Cameroon", "code": "CM", "flag": "🇨🇲"}, {"name": "Canada", "code": "CA", "flag": "🇨🇦"}, {"name": "Cayman Islands", "code": "KY", "flag": "🇰🇾"}, {"name": "Central African Republic", "code": "CF", "flag": "🇨🇫"}, {"name": "Chad", "code": "TD", "flag": "🇹🇩"}, {"name": "Chile", "code": "CL", "flag": "🇨🇱"}, {"name": "China", "code": "CN", "flag": "🇨🇳"}, {"name": "Christmas Island", "code": "CX", "flag": "🇨🇽"}, {"name": "Cocos (Keeling) Islands", "code": "CC", "flag": "🇨🇨"}, {"name": "Colombia", "code": "CO", "flag": "🇨🇴"}, {"name": "Comoros", "code": "KM", "flag": "🇰🇲"}, {"name": "Congo", "code": "CG", "flag": "🇨🇬"}, {"name": "Congo, The Democratic Republic of the", "code": "CD", "flag": "🇨🇩"}, {"name": "Cook Islands", "code": "CK", "flag": "🇨🇰"}, {"name": "Costa Rica", "code": "CR", "flag": "🇨🇷"}, {"name": "Croatia", "code": "HR", "flag": "🇭🇷"}, {"name": "Cuba", "code": "CU", "flag": "🇨🇺"}, {"name": "Curaçao", "code": "CW", "flag": "🇨🇼"}, {"name": "Cyprus", "code": "CY", "flag": "🇨🇾"}, {"name": "Czechia", "code": "CZ", "flag": "🇨🇿"}, {"name": "Côte d'Ivoire", "code": "CI", "flag": "🇨🇮"}, {"name": "Denmark", "code": "DK", "flag": "🇩🇰"}, {"name": "Djibouti", "code": "DJ", "flag": "🇩🇯"}, {"name": "Dominica", "code": "DM", "flag": "🇩🇲"}, {"name": "Dominican Republic", "code": "DO", "flag": "🇩🇴"}, {"name": "Ecuador", "code": "EC", "flag": "🇪🇨"}, {"name": "Egypt", "code": "EG", "flag": "🇪🇬"}, {"name": "El Salvador", "code": "SV", "flag": "🇸🇻"}, {"name": "Equatorial Guinea", "code": "GQ", "flag": "🇬🇶"}, {"name": "Eritrea", "code": "ER", "flag": "🇪🇷"}, {"name": "Estonia", "code": "EE", "flag": "🇪🇪"}, {"name": "Eswatini", "code": "SZ", "flag": "🇸🇿"}, {"name": "Ethiopia", "code": "ET", "flag": "🇪🇹"}, {"name": "Falkland Islands (Malvinas)", "code": "FK", "flag": "🇫🇰"}, {"name": "Faroe Islands", "code": "FO", "flag": "🇫🇴"}, {"name": "Fiji", "code": "FJ", "flag": "🇫🇯"}, {"name": "Finland", "code": "FI", "flag": "🇫🇮"}, {"name": "France", "code": "FR", "flag": "🇫🇷"}, {"name": "French Guiana", "code": "GF", "flag": "🇬🇫"}, {"name": "French Polynesia", "code": "PF", "flag": "🇵🇫"}, {"name": "French Southern Territories", "code": "TF", "flag": "🇹🇫"}, {"name": "Gabon", "code": "GA", "flag": "🇬🇦"}, {"name": "Gambia", "code": "GM", "flag": "🇬🇲"}, {"name": "Georgia", "code": "GE", "flag": "🇬🇪"}, {"name": "Germany", "code": "DE", "flag": "🇩🇪"}, {"name": "Ghana", "code": "GH", "flag": "🇬🇭"}, {"name": "Gibraltar", "code": "GI", "flag": "🇬🇮"}, {"name": "Greece", "code": "GR", "flag": "🇬🇷"}, {"name": "Greenland", "code": "GL", "flag": "🇬🇱"}, {"name": "Grenada", "code": "GD", "flag": "🇬🇩"}, {"name": "Guadeloupe", "code": "GP", "flag": "🇬🇵"}, {"name": "Guam", "code": "GU", "flag": "🇬🇺"}, {"name": "Guatemala", "code": "GT", "flag": "🇬🇹"}, {"name": "Guernsey", "code": "GG", "flag": "🇬🇬"}, {"name": "Guinea", "code": "GN", "flag": "🇬🇳"}, {"name": "Guinea-Bissau", "code": "GW", "flag": "🇬🇼"}, {"name": "Guyana", "code": "GY", "flag": "🇬🇾"}, {"name": "Haiti", "code": "HT", "flag": "🇭🇹"}, {"name": "Heard Island and McDonald Islands", "code": "HM", "flag": "🇭🇲"}, {"name": "Holy See (Vatican City State)", "code": "VA", "flag": "🇻🇦"}, {"name": "Honduras", "code": "HN", "flag": "🇭🇳"}, {"name": "Hong Kong", "code": "HK", "flag": "🇭🇰"}, {"name": "Hungary", "code": "HU", "flag": "🇭🇺"}, {"name": "Iceland", "code": "IS", "flag": "🇮🇸"}, {"name": "India", "code": "IN", "flag": "🇮🇳"}, {"name": "Indonesia", "code": "ID", "flag": "🇮🇩"}, {"name": "Iran, Islamic Republic of", "code": "IR", "flag": "🇮🇷"}, {"name": "Iraq", "code": "IQ", "flag": "🇮🇶"}, {"name": "Ireland", "code": "IE", "flag": "🇮🇪"}, {"name": "Isle of Man", "code": "IM", "flag": "🇮🇲"}, {"name": "Israel", "code": "IL", "flag": "🇮🇱"}, {"name": "Italy", "code": "IT", "flag": "🇮🇹"}, {"name": "Jamaica", "code": "JM", "flag": "🇯🇲"}, {"name": "Japan", "code": "JP", "flag": "🇯🇵"}, {"name": "Jersey", "code": "JE", "flag": "🇯🇪"}, {"name": "Jordan", "code": "JO", "flag": "🇯🇴"}, {"name": "Kazakhstan", "code": "KZ", "flag": "🇰🇿"}, {"name": "Kenya", "code": "KE", "flag": "🇰🇪"}, {"name": "Kiribati", "code": "KI", "flag": "🇰🇮"}, {"name": "Korea, Democratic People's Republic of", "code": "KP", "flag": "🇰🇵"}, {"name": "Korea, Republic of", "code": "KR", "flag": "🇰🇷"}, {"name": "Kuwait", "code": "KW", "flag": "🇰🇼"}, {"name": "Kyrgyzstan", "code": "KG", "flag": "🇰🇬"}, {"name": "Lao People's Democratic Republic", "code": "LA", "flag": "🇱🇦"}, {"name": "Latvia", "code": "LV", "flag": "🇱🇻"}, {"name": "Lebanon", "code": "LB", "flag": "🇱🇧"}, {"name": "Lesotho", "code": "LS", "flag": "🇱🇸"}, {"name": "Liberia", "code": "LR", "flag": "🇱🇷"}, {"name": "Libya", "code": "LY", "flag": "🇱🇾"}, {"name": "Liechtenstein", "code": "LI", "flag": "🇱🇮"}, {"name": "Lithuania", "code": "LT", "flag": "🇱🇹"}, {"name": "Luxembourg", "code": "LU", "flag": "🇱🇺"}, {"name": "Macao", "code": "MO", "flag": "🇲🇴"}, {"name": "Madagascar", "code": "MG", "flag": "🇲🇬"}, {"name": "Malawi", "code": "MW", "flag": "🇲🇼"}, {"name": "Malaysia", "code": "MY", "flag": "🇲🇾"}, {"name": "Maldives", "code": "MV", "flag": "🇲🇻"}, {"name": "Mali", "code": "ML", "flag": "🇲🇱"}, {"name": "Malta", "code": "MT", "flag": "🇲🇹"}, {"name": "Marshall Islands", "code": "MH", "flag": "🇲🇭"}, {"name": "Martinique", "code": "MQ", "flag": "🇲🇶"}, {"name": "Mauritania", "code": "MR", "flag": "🇲🇷"}, {"name": "Mauritius", "code": "MU", "flag": "🇲🇺"}, {"name": "Mayotte", "code": "YT", "flag": "🇾🇹"}, {"name": "Mexico", "code": "MX", "flag": "🇲🇽"}, {"name": "Micronesia, Federated States of", "code": "FM", "flag": "🇫🇲"}, {"name": "Moldova, Republic of", "code": "MD", "flag": "🇲🇩"}, {"name": "Monaco", "code": "MC", "flag": "🇲🇨"}, {"name": "Mongolia", "code": "MN", "flag": "🇲🇳"}, {"name": "Montenegro", "code": "ME", "flag": "🇲🇪"}, {"name": "Montserrat", "code": "MS", "flag": "🇲🇸"}, {"name": "Morocco", "code": "MA", "flag": "🇲🇦"}, {"name": "Mozambique", "code": "MZ", "flag": "🇲🇿"}, {"name": "Myanmar", "code": "MM", "flag": "🇲🇲"}, {"name": "Namibia", "code": "NA", "flag": "🇳🇦"}, {"name": "Nauru", "code": "NR", "flag": "🇳🇷"}, {"name": "Nepal", "code": "NP", "flag": "🇳🇵"}, {"name": "Netherlands", "code": "NL", "flag": "🇳🇱"}, {"name": "New Caledonia", "code": "NC", "flag": "🇳🇨"}, {"name": "New Zealand", "code": "NZ", "flag": "🇳🇿"}, {"name": "Nicaragua", "code": "NI", "flag": "🇳🇮"}, {"name": "Niger", "code": "NE", "flag": "🇳🇪"}, {"name": "Nigeria", "code": "NG", "flag": "🇳🇬"}, {"name": "Niue", "code": "NU", "flag": "🇳🇺"}, {"name": "Norfolk Island", "code": "NF", "flag": "🇳🇫"}, {"name": "North Macedonia", "code": "MK", "flag": "🇲🇰"}, {"name": "Northern Mariana Islands", "code": "MP", "flag": "🇲🇵"}, {"name": "Norway", "code": "NO", "flag": "🇳🇴"}, {"name": "Oman", "code": "OM", "flag": "🇴🇲"}, {"name": "Pakistan", "code": "PK", "flag": "🇵🇰"}, {"name": "Palau", "code": "PW", "flag": "🇵🇼"}, {"name": "Palestine, State of", "code": "PS", "flag": "🇵🇸"}, {"name": "Panama", "code": "PA", "flag": "🇵🇦"}, {"name": "Papua New Guinea", "code": "PG", "flag": "🇵🇬"}, {"name": "Paraguay", "code": "PY", "flag": "🇵🇾"}, {"name": "Peru", "code": "PE", "flag": "🇵🇪"}, {"name": "Philippines", "code": "PH", "flag": "🇵🇭"}, {"name": "Pitcairn", "code": "PN", "flag": "🇵🇳"}, {"name": "Poland", "code": "PL", "flag": "🇵🇱"}, {"name": "Portugal", "code": "PT", "flag": "🇵🇹"}, {"name": "Puerto Rico", "code": "PR", "flag": "🇵🇷"}, {"name": "Qatar", "code": "QA", "flag": "🇶🇦"}, {"name": "Romania", "code": "RO", "flag": "🇷🇴"}, {"name": "Russian Federation", "code": "RU", "flag": "🇷🇺"}, {"name": "Rwanda", "code": "RW", "flag": "🇷🇼"}, {"name": "Réunion", "code": "RE", "flag": "🇷🇪"}, {"name": "Saint Barthélemy", "code": "BL", "flag": "🇧🇱"}, {"name": "Saint Helena, Ascension and Tristan da Cunha", "code": "SH", "flag": "🇸🇭"}, {"name": "Saint Kitts and Nevis", "code": "KN", "flag": "🇰🇳"}, {"name": "Saint Lucia", "code": "LC", "flag": "🇱🇨"}, {"name": "Saint Martin (French part)", "code": "MF", "flag": "🇲🇫"}, {"name": "Saint Pierre and Miquelon", "code": "PM", "flag": "🇵🇲"}, {"name": "Saint Vincent and the Grenadines", "code": "VC", "flag": "🇻🇨"}, {"name": "Samoa", "code": "WS", "flag": "🇼🇸"}, {"name": "San Marino", "code": "SM", "flag": "🇸🇲"}, {"name": "Sao Tome and Principe", "code": "ST", "flag": "🇸🇹"}, {"name": "Saudi Arabia", "code": "SA", "flag": "🇸🇦"}, {"name": "Senegal", "code": "SN", "flag": "🇸🇳"}, {"name": "Serbia", "code": "RS", "flag": "🇷🇸"}, {"name": "Seychelles", "code": "SC", "flag": "🇸🇨"}, {"name": "Sierra Leone", "code": "SL", "flag": "🇸🇱"}, {"name": "Singapore", "code": "SG", "flag": "🇸🇬"}, {"name": "Sint Maarten (Dutch part)", "code": "SX", "flag": "🇸🇽"}, {"name": "Slovakia", "code": "SK", "flag": "🇸🇰"}, {"name": "Slovenia", "code": "SI", "flag": "🇸🇮"}, {"name": "Solomon Islands", "code": "SB", "flag": "🇸🇧"}, {"name": "Somalia", "code": "SO", "flag": "🇸🇴"}, {"name": "South Africa", "code": "ZA", "flag": "🇿🇦"}, {"name": "South Georgia and the South Sandwich Islands", "code": "GS", "flag": "🇬🇸"}, {"name": "South Sudan", "code": "SS", "flag": "🇸🇸"}, {"name": "Spain", "code": "ES", "flag": "🇪🇸"}, {"name": "Sri Lanka", "code": "LK", "flag": "🇱🇰"}, {"name": "Sudan", "code": "SD", "flag": "🇸🇩"}, {"name": "Suriname", "code": "SR", "flag": "🇸🇷"}, {"name": "Svalbard and Jan Mayen", "code": "SJ", "flag": "🇸🇯"}, {"name": "Sweden", "code": "SE", "flag": "🇸🇪"}, {"name": "Switzerland", "code": "CH", "flag": "🇨🇭"}, {"name": "Syrian Arab Republic", "code": "SY", "flag": "🇸🇾"}, {"name": "Taiwan, Province of China", "code": "TW", "flag": "🇹🇼"}, {"name": "Tajikistan", "code": "TJ", "flag": "🇹🇯"}, {"name": "Tanzania, United Republic of", "code": "TZ", "flag": "🇹🇿"}, {"name": "Thailand", "code": "TH", "flag": "🇹🇭"}, {"name": "Timor-Leste", "code": "TL", "flag": "🇹🇱"}, {"name": "Togo", "code": "TG", "flag": "🇹🇬"}, {"name": "Tokelau", "code": "TK", "flag": "🇹🇰"}, {"name": "Tonga", "code": "TO", "flag": "🇹🇴"}, {"name": "Trinidad and Tobago", "code": "TT", "flag": "🇹🇹"}, {"name": "Tunisia", "code": "TN", "flag": "🇹🇳"}, {"name": "Turkmenistan", "code": "TM", "flag": "🇹🇲"}, {"name": "Turks and Caicos Islands", "code": "TC", "flag": "🇹🇨"}, {"name": "Tuvalu", "code": "TV", "flag": "🇹🇻"}, {"name": "Türkiye", "code": "TR", "flag": "🇹🇷"}, {"name": "Uganda", "code": "UG", "flag": "🇺🇬"}, {"name": "Ukraine", "code": "UA", "flag": "🇺🇦"}, {"name": "United Arab Emirates", "code": "AE", "flag": "🇦🇪"}, {"name": "United Kingdom", "code": "GB", "flag": "🇬🇧"}, {"name": "United States", "code": "US", "flag": "🇺🇸"}, {"name": "United States Minor Outlying Islands", "code": "UM", "flag": "🇺🇲"}, {"name": "Uruguay", "code": "UY", "flag": "🇺🇾"}, {"name": "Uzbekistan", "code": "UZ", "flag": "🇺🇿"}, {"name": "Vanuatu", "code": "VU", "flag": "🇻🇺"}, {"name": "Venezuela, Bolivarian Republic of", "code": "VE", "flag": "🇻🇪"}, {"name": "Viet Nam", "code": "VN", "flag": "🇻🇳"}, {"name": "Virgin Islands, British", "code": "VG", "flag": "🇻🇬"}, {"name": "Virgin Islands, U.S.", "code": "VI", "flag": "🇻🇮"}, {"name": "Wallis and Futuna", "code": "WF", "flag": "🇼🇫"}, {"name": "Western Sahara", "code": "EH", "flag": "🇪🇭"}, {"name": "Yemen", "code": "YE", "flag": "🇾🇪"}, {"name": "Zambia", "code": "ZM", "flag": "🇿🇲"}, {"name": "Zimbabwe", "code": "ZW", "flag": "🇿🇼"}, {"name": "Åland Islands", "code": "AX", "flag": "🇦🇽"}];
const US_STATES = [{"name": "Alabama", "code": "AL"}, {"name": "Alaska", "code": "AK"}, {"name": "Arizona", "code": "AZ"}, {"name": "Arkansas", "code": "AR"}, {"name": "California", "code": "CA"}, {"name": "Colorado", "code": "CO"}, {"name": "Connecticut", "code": "CT"}, {"name": "Delaware", "code": "DE"}, {"name": "Florida", "code": "FL"}, {"name": "Georgia", "code": "GA"}, {"name": "Hawaii", "code": "HI"}, {"name": "Idaho", "code": "ID"}, {"name": "Illinois", "code": "IL"}, {"name": "Indiana", "code": "IN"}, {"name": "Iowa", "code": "IA"}, {"name": "Kansas", "code": "KS"}, {"name": "Kentucky", "code": "KY"}, {"name": "Louisiana", "code": "LA"}, {"name": "Maine", "code": "ME"}, {"name": "Maryland", "code": "MD"}, {"name": "Massachusetts", "code": "MA"}, {"name": "Michigan", "code": "MI"}, {"name": "Minnesota", "code": "MN"}, {"name": "Mississippi", "code": "MS"}, {"name": "Missouri", "code": "MO"}, {"name": "Montana", "code": "MT"}, {"name": "Nebraska", "code": "NE"}, {"name": "Nevada", "code": "NV"}, {"name": "New Hampshire", "code": "NH"}, {"name": "New Jersey", "code": "NJ"}, {"name": "New Mexico", "code": "NM"}, {"name": "New York", "code": "NY"}, {"name": "North Carolina", "code": "NC"}, {"name": "North Dakota", "code": "ND"}, {"name": "Ohio", "code": "OH"}, {"name": "Oklahoma", "code": "OK"}, {"name": "Oregon", "code": "OR"}, {"name": "Pennsylvania", "code": "PA"}, {"name": "Rhode Island", "code": "RI"}, {"name": "South Carolina", "code": "SC"}, {"name": "South Dakota", "code": "SD"}, {"name": "Tennessee", "code": "TN"}, {"name": "Texas", "code": "TX"}, {"name": "Utah", "code": "UT"}, {"name": "Vermont", "code": "VT"}, {"name": "Virginia", "code": "VA"}, {"name": "Washington", "code": "WA"}, {"name": "West Virginia", "code": "WV"}, {"name": "Wisconsin", "code": "WI"}, {"name": "Wyoming", "code": "WY"}, {"name": "District of Columbia", "code": "DC"}];
const US_CITIES = {"AL": ["Birmingham", "Montgomery", "Huntsville", "Mobile"], "AK": ["Anchorage", "Fairbanks", "Juneau"], "AZ": ["Phoenix", "Tucson", "Mesa", "Scottsdale", "Tempe"], "AR": ["Little Rock", "Fayetteville", "Fort Smith"], "CA": ["Los Angeles", "San Francisco", "San Diego", "San Jose", "Sacramento", "Oakland", "Fresno"], "CO": ["Denver", "Colorado Springs", "Boulder", "Aurora"], "CT": ["Hartford", "New Haven", "Stamford", "Bridgeport"], "DE": ["Wilmington", "Dover", "Newark"], "FL": ["Miami", "Orlando", "Tampa", "Jacksonville", "Tallahassee", "Fort Lauderdale"], "GA": ["Atlanta", "Savannah", "Augusta", "Athens"], "HI": ["Honolulu", "Hilo", "Kailua"], "ID": ["Boise", "Meridian", "Idaho Falls"], "IL": ["Chicago", "Springfield", "Naperville", "Peoria"], "IN": ["Indianapolis", "Fort Wayne", "Bloomington"], "IA": ["Des Moines", "Cedar Rapids", "Iowa City"], "KS": ["Wichita", "Overland Park", "Kansas City", "Topeka"], "KY": ["Louisville", "Lexington", "Bowling Green"], "LA": ["New Orleans", "Baton Rouge", "Shreveport", "Lafayette"], "ME": ["Portland", "Bangor", "Augusta"], "MD": ["Baltimore", "Annapolis", "Frederick", "Rockville"], "MA": ["Boston", "Cambridge", "Worcester", "Springfield"], "MI": ["Detroit", "Grand Rapids", "Ann Arbor", "Lansing"], "MN": ["Minneapolis", "Saint Paul", "Rochester", "Duluth"], "MS": ["Jackson", "Gulfport", "Biloxi"], "MO": ["Kansas City", "St. Louis", "Springfield", "Columbia"], "MT": ["Billings", "Missoula", "Bozeman", "Helena"], "NE": ["Omaha", "Lincoln", "Bellevue"], "NV": ["Las Vegas", "Reno", "Henderson", "Carson City"], "NH": ["Manchester", "Nashua", "Concord"], "NJ": ["Newark", "Jersey City", "Trenton", "Princeton"], "NM": ["Albuquerque", "Santa Fe", "Las Cruces"], "NY": ["New York City", "Buffalo", "Rochester", "Albany", "Syracuse"], "NC": ["Charlotte", "Raleigh", "Durham", "Greensboro", "Asheville"], "ND": ["Fargo", "Bismarck", "Grand Forks"], "OH": ["Columbus", "Cleveland", "Cincinnati", "Toledo", "Akron"], "OK": ["Oklahoma City", "Tulsa", "Norman"], "OR": ["Portland", "Eugene", "Salem", "Bend"], "PA": ["Philadelphia", "Pittsburgh", "Harrisburg", "Allentown"], "RI": ["Providence", "Warwick", "Newport"], "SC": ["Charleston", "Columbia", "Greenville", "Myrtle Beach"], "SD": ["Sioux Falls", "Rapid City", "Pierre"], "TN": ["Nashville", "Memphis", "Knoxville", "Chattanooga"], "TX": ["Houston", "Dallas", "Austin", "San Antonio", "Fort Worth", "El Paso"], "UT": ["Salt Lake City", "Provo", "Ogden", "Park City"], "VT": ["Burlington", "Montpelier", "Rutland"], "VA": ["Virginia Beach", "Richmond", "Arlington", "Norfolk", "Alexandria"], "WA": ["Seattle", "Spokane", "Tacoma", "Bellevue", "Olympia"], "WV": ["Charleston", "Huntington", "Morgantown"], "WI": ["Milwaukee", "Madison", "Green Bay"], "WY": ["Cheyenne", "Casper", "Jackson"], "DC": ["Washington"]};
const COUNTRY_CITIES = {"CA": ["Toronto", "Montreal", "Vancouver", "Calgary", "Ottawa"], "GB": ["London", "Manchester", "Birmingham", "Edinburgh", "Glasgow"], "AU": ["Sydney", "Melbourne", "Brisbane", "Perth", "Adelaide"], "DE": ["Berlin", "Munich", "Hamburg", "Frankfurt", "Cologne"], "FR": ["Paris", "Marseille", "Lyon", "Toulouse", "Nice"], "IN": ["Mumbai", "Delhi", "Bangalore", "Hyderabad", "Chennai"], "JP": ["Tokyo", "Osaka", "Kyoto", "Yokohama", "Nagoya"], "BR": ["São Paulo", "Rio de Janeiro", "Brasília", "Salvador"], "MX": ["Mexico City", "Guadalajara", "Monterrey", "Cancún"], "IT": ["Rome", "Milan", "Naples", "Turin", "Florence"], "ES": ["Madrid", "Barcelona", "Valencia", "Seville"], "NL": ["Amsterdam", "Rotterdam", "The Hague", "Utrecht"], "CN": ["Beijing", "Shanghai", "Guangzhou", "Shenzhen"], "ZA": ["Johannesburg", "Cape Town", "Durban", "Pretoria"], "AE": ["Dubai", "Abu Dhabi", "Sharjah"], "SG": ["Singapore"], "IE": ["Dublin", "Cork", "Galway"], "NZ": ["Auckland", "Wellington", "Christchurch"], "SE": ["Stockholm", "Gothenburg", "Malmö"], "NG": ["Lagos", "Abuja", "Kano"]};

// Curated popular English-speaking markets (English official or major 1st/2nd language)
const POPULAR_ENGLISH = ["GB","CA","AU","IN","IE","NZ","ZA","SG","PH","NG","KE","GH","PK","MY","HK","JM","TT","GY","ZW","ZM","UG","TZ","BW","RW","LK","MU","MT","BS","BB","BZ","BN"];
const POPULAR_STATES = ["CA", "TX", "FL", "NY", "PA", "IL", "OH", "GA", "NC", "MI", "NJ", "VA", "WA", "AZ", "MA"];
const POPULAR_CITIES = {"CA": ["Los Angeles", "San Francisco", "San Diego", "San Jose"], "TX": ["Houston", "Dallas", "Austin", "San Antonio"], "FL": ["Miami", "Orlando", "Tampa", "Jacksonville"], "NY": ["New York City", "Buffalo", "Rochester"], "IL": ["Chicago", "Naperville"], "AZ": ["Phoenix", "Tucson", "Scottsdale"], "WA": ["Seattle", "Bellevue", "Tacoma"], "GA": ["Atlanta", "Savannah"], "NC": ["Charlotte", "Raleigh", "Durham"], "PA": ["Philadelphia", "Pittsburgh"], "OH": ["Columbus", "Cleveland", "Cincinnati"], "MI": ["Detroit", "Grand Rapids", "Ann Arbor"], "NJ": ["Newark", "Jersey City"], "VA": ["Virginia Beach", "Richmond", "Arlington"], "MA": ["Boston", "Cambridge", "Worcester"], "CO": ["Denver", "Boulder"], "NV": ["Las Vegas", "Reno"], "TN": ["Nashville", "Memphis"], "OR": ["Portland", "Eugene"], "MO": ["Kansas City", "St. Louis"], "MD": ["Baltimore", "Annapolis"], "MN": ["Minneapolis", "Saint Paul"], "LA": ["New Orleans", "Baton Rouge"], "IN": ["Indianapolis"], "WI": ["Milwaukee", "Madison"], "UT": ["Salt Lake City", "Provo"], "SC": ["Charleston", "Columbia", "Greenville"]};

// ==== Categories ====
const CATEGORIES = [
  { id: "home", label: "Home & Repair", icon: "🏠" },
  { id: "auto", label: "Automotive", icon: "🚗" },
  { id: "professional", label: "Professional Services", icon: "💼" },
  { id: "legal", label: "Legal & Financial", icon: "⚖️" },
  { id: "creative", label: "Creative & Design", icon: "🎨" },
  { id: "tech", label: "Tech & AI", icon: "🤖" },
  { id: "marketing", label: "Marketing & Media", icon: "📣" },
  { id: "wellness", label: "Health & Wellness", icon: "🩺" },
  { id: "beauty", label: "Beauty & Personal Care", icon: "💇" },
  { id: "food", label: "Food & Catering", icon: "🍽️" },
  { id: "events", label: "Events & Entertainment", icon: "🎉" },
  { id: "education", label: "Education & Tutoring", icon: "📚" },
  { id: "realestate", label: "Real Estate", icon: "🔑" },
  { id: "retail", label: "Retail & Shopping", icon: "🛍️" },
  { id: "pets", label: "Pets & Animals", icon: "🐾" },
  { id: "trades", label: "Skilled Trades", icon: "🔧" },
];

function seededListings(placeKey) {
  let seed = 0;
  for (let i = 0; i < placeKey.length; i++) seed = (seed * 31 + placeKey.charCodeAt(i)) >>> 0;
  const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  const NAMES = ["Summit","Ironwood","Blue Harbor","Copper","North Star","Evergreen","Redline","Meridian","Willow","Anchor","Bright","Vantage","Cobalt","Granite","Silverleaf","Harbor","Pinnacle","Cedar","Atlas","Kingfisher"];
  const SUFFIX = ["Group","Co.","Services","& Sons","Studio","Works","Collective","Partners","LLC","Labs"];
  const count = 4 + Math.floor(rnd() * 5);
  const out = [];
  for (let i = 0; i < count; i++) {
    const cat = CATEGORIES[Math.floor(rnd() * CATEGORIES.length)];
    out.push({
      id: `${placeKey}-${i}`,
      name: `${NAMES[Math.floor(rnd()*NAMES.length)]} ${SUFFIX[Math.floor(rnd()*SUFFIX.length)]}`,
      category: cat.id,
      rating: Math.round((3.6 + rnd() * 1.4) * 10) / 10,
      reviews: 5 + Math.floor(rnd() * 400),
      verified: rnd() > 0.5,
      tagline: `Trusted ${cat.label.toLowerCase()} serving the local area.`,
    });
  }
  return out;
}

function Stars({ rating, size = 14 }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 3 }}>
      <Star size={size} fill="var(--star)" strokeWidth={0} style={{ color: "var(--star)" }} />
      <span style={{ color: "var(--ink)", fontWeight: 700, fontSize: 13 }}>{rating.toFixed(1)}</span>
    </span>
  );
}

export default function DirectoryBrowse() {
  const [nav, setNav] = useState({ country: null, state: null, city: null });
  const [query, setQuery] = useState("");
  const [catFilter, setCatFilter] = useState("all");
  const [submitOpen, setSubmitOpen] = useState(false);
  const [userListings, setUserListings] = useState([]);

  const isUS = nav.country?.code === "US";

  let level = "countries";
  if (nav.country) {
    if (isUS) {
      if (nav.state && nav.city) level = "listings";
      else if (nav.state) level = "cities";
      else level = "states";
    } else {
      if (nav.city) level = "listings";
      else level = "cities";
    }
  }

  const cityKey = useMemo(() => {
    if (level !== "listings") return null;
    return isUS ? `US-${nav.state.code}-${nav.city}` : `${nav.country.code}-${nav.city}`;
  }, [level, isUS, nav]);

  const listings = useMemo(() => {
    if (!cityKey) return [];
    const base = seededListings(cityKey);
    const mine = userListings.filter((l) => l.cityKey === cityKey);
    return [...mine, ...base];
  }, [cityKey, userListings]);

  const filteredListings = useMemo(() => {
    return listings.filter((l) => {
      const q = query.toLowerCase();
      const mq = !q || l.name.toLowerCase().includes(q) || l.tagline.toLowerCase().includes(q);
      const mc = catFilter === "all" || l.category === catFilter;
      return mq && mc;
    });
  }, [listings, query, catFilter]);

  const go = (patch) => { setNav((n) => ({ ...n, ...patch })); setQuery(""); setCatFilter("all"); };

  const crumbs = [{ label: "Home", onClick: () => go({ country: null, state: null, city: null }) }];
  if (nav.country) crumbs.push({ label: `${nav.country.flag} ${nav.country.name}`, onClick: () => go({ state: null, city: null }) });
  if (nav.state) crumbs.push({ label: nav.state.name, onClick: () => go({ city: null }) });
  if (nav.city) crumbs.push({ label: nav.city, onClick: () => {} });

  return (
    <div className="ml">
      <MLStyle />

      <header className="ml-topnav">
        <div className="ml-container ml-topnav-inner">
          <button className="ml-logo" onClick={() => go({ country: null, state: null, city: null })}>
            Monster<span>List</span>
          </button>
          <button className="ml-btn-primary" onClick={() => setSubmitOpen(true)}>
            <Plus size={16} /> Add a business
          </button>
        </div>
      </header>

      {level === "countries" && (
        <section className="ml-hero">
          <div className="ml-container">
            <p className="ml-eyebrow">The worldwide small-business directory</p>
            <h1 className="ml-hero-title">Find trusted businesses,<br/>anywhere on the map.</h1>
            <p className="ml-hero-sub">Browse listings across {COUNTRIES.length} countries. Pick a place to start.</p>
            <div className="ml-hero-search">
              <Search size={20} style={{ color: "var(--faint)" }} />
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search countries…" className="ml-search-input" />
            </div>
          </div>
        </section>
      )}

      <div className="ml-container">
        <nav className="ml-crumbs">
          {crumbs.map((c, i) => (
            <span key={i} style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
              {i > 0 && <ChevronRight size={14} style={{ color: "var(--faint)" }} />}
              <button className={`ml-crumb ${i === crumbs.length - 1 ? "ml-crumb-active" : ""}`} onClick={c.onClick}>{c.label}</button>
            </span>
          ))}
        </nav>
      </div>

      {level !== "countries" && (
        <div className="ml-container" style={{ paddingTop: 14 }}>
          <div className="ml-search">
            <Search size={20} style={{ color: "var(--faint)" }} />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={level === "states" ? "Search states…" : level === "cities" ? "Search cities…" : "Search businesses…"}
              className="ml-search-input"
            />
            {query && <button onClick={() => setQuery("")} className="ml-search-clear"><X size={16} /></button>}
          </div>
        </div>
      )}

      <main className="ml-container" style={{ paddingTop: 26, paddingBottom: 60 }}>
        {level === "countries" && <CountryGrid query={query} onPick={(c) => go({ country: c, state: null, city: null })} />}
        {level === "states" && <StateGrid query={query} onPick={(s) => go({ state: s, city: null })} />}
        {level === "cities" && <CityGrid query={query} country={nav.country} state={nav.state} isUS={isUS} onPick={(city) => go({ city })} />}
        {level === "listings" && <ListingsView listings={filteredListings} catFilter={catFilter} setCatFilter={setCatFilter} place={nav.city} />}
      </main>

      <footer className="ml-footer">
        <div className="ml-container ml-footer-inner">
          <span className="ml-logo" style={{ fontSize: 16 }}>Monster<span>List</span></span>
          <span className="ml-footer-note">A small-business directory open to the world · monsterlist.org</span>
        </div>
      </footer>

      {submitOpen && (
        <SubmitModal
          nav={nav}
          isUS={isUS}
          onClose={() => setSubmitOpen(false)}
          onSubmit={(entry) => { setUserListings((u) => [entry, ...u]); setSubmitOpen(false); }}
        />
      )}
    </div>
  );
}

function SectionHead({ icon, title, extra }) {
  return (
    <div className="ml-sectionhead">
      <span className="ml-sectionhead-title">{icon} {title}</span>
      {extra && <span className="ml-sectionhead-extra">{extra}</span>}
    </div>
  );
}

function CountryTile({ c, onPick }) {
  return (
    <button className="ml-tile" onClick={() => onPick(c)}>
      <span className="ml-tile-flag">{c.flag}</span>
      <span className="ml-tile-label">{c.name}</span>
      <ChevronRight size={16} className="ml-tile-arrow" />
    </button>
  );
}

function CountryGrid({ query, onPick }) {
  const q = query.toLowerCase();
  const match = (c) => c.name.toLowerCase().includes(q);

  const us = COUNTRIES.find((c) => c.code === "US");
  const popularSet = new Set(POPULAR_ENGLISH);

  // Popular section keeps the curated order (by market importance)
  const popular = POPULAR_ENGLISH
    .map((code) => COUNTRIES.find((c) => c.code === code))
    .filter((c) => c && match(c));

  // Rest = everything except US and popular, alphabetical (COUNTRIES is already sorted)
  const rest = COUNTRIES.filter((c) => c.code !== "US" && !popularSet.has(c.code) && match(c));

  const usMatches = us && match(us);
  const nothing = !usMatches && popular.length === 0 && rest.length === 0;

  return (
    <>
      {usMatches && (
        <section className="ml-country-section">
          <SectionHead icon={<Globe2 size={16} />} title="United States" />
          <div className="ml-grid">
            <CountryTile c={us} onPick={onPick} />
          </div>
        </section>
      )}

      {popular.length > 0 && (
        <section className="ml-country-section">
          <SectionHead icon={<Globe2 size={16} />} title="Popular countries" extra={`${popular.length}`} />
          <div className="ml-grid">
            {popular.map((c) => <CountryTile key={c.code} c={c} onPick={onPick} />)}
          </div>
        </section>
      )}

      {rest.length > 0 && (
        <section className="ml-country-section">
          <SectionHead icon={<Globe2 size={16} />} title="All countries" extra={`${rest.length}`} />
          <div className="ml-grid">
            {rest.map((c) => <CountryTile key={c.code} c={c} onPick={onPick} />)}
          </div>
        </section>
      )}

      {nothing && <EmptyState msg="No countries match your search." />}
    </>
  );
}

function StateTile({ s, onPick }) {
  return (
    <button className="ml-tile" onClick={() => onPick(s)}>
      <span className="ml-tile-code">{s.code}</span>
      <span className="ml-tile-label">{s.name}</span>
      <ChevronRight size={16} className="ml-tile-arrow" />
    </button>
  );
}

function StateGrid({ query, onPick }) {
  const list = US_STATES.filter((s) => s.name.toLowerCase().includes(query.toLowerCase()));
  return (
    <>
      <SectionHead icon={<Grid3x3 size={16} />} title={`${list.length} states & districts`} />
      {list.length === 0 ? (
        <EmptyState msg="No states match your search." />
      ) : (
        <div className="ml-grid">
          {list.map((s) => <StateTile key={s.code} s={s} onPick={onPick} />)}
        </div>
      )}
    </>
  );
}

function CityTile({ c, onPick }) {
  return (
    <button className="ml-tile" onClick={() => onPick(c)}>
      <MapPin size={16} style={{ color: "var(--accent)" }} />
      <span className="ml-tile-label">{c}</span>
      <ChevronRight size={16} className="ml-tile-arrow" />
    </button>
  );
}

function CityGrid({ query, country, state, isUS, onPick }) {
  let cities = [];
  if (isUS) cities = US_CITIES[state.code] || [];
  else cities = COUNTRY_CITIES[country.code] || [`${country.name} City`];
  const placeName = isUS ? state.name : country.name;
  const list = cities.filter((c) => c.toLowerCase().includes(query.toLowerCase()));

  return (
    <>
      <SectionHead icon={<MapPin size={16} />} title={`${list.length} cities in ${placeName}`} />
      {list.length === 0 ? (
        <EmptyState msg="No cities listed here yet — add the first business to seed this location." />
      ) : (
        <div className="ml-grid">
          {list.map((c) => <CityTile key={c} c={c} onPick={onPick} />)}
        </div>
      )}
    </>
  );
}

function ListingsView({ listings, catFilter, setCatFilter, place }) {
  return (
    <>
      <SectionHead icon={<MapPin size={16} />} title={`Businesses in ${place}`} extra={`${listings.length} listing${listings.length !== 1 ? "s" : ""}`} />
      <div className="ml-chips">
        <button className={`ml-chip ${catFilter === "all" ? "ml-chip-on" : ""}`} onClick={() => setCatFilter("all")}>All</button>
        {CATEGORIES.map((c) => (
          <button key={c.id} className={`ml-chip ${catFilter === c.id ? "ml-chip-on" : ""}`} onClick={() => setCatFilter(c.id)}>
            <span>{c.icon}</span> {c.label}
          </button>
        ))}
      </div>
      {listings.length === 0 ? (
        <EmptyState msg="No businesses match this category yet. Be the first to add one." />
      ) : (
        <div className="ml-listing-grid">
          {listings.map((l) => {
            const cat = CATEGORIES.find((c) => c.id === l.category);
            return (
              <div key={l.id} className="ml-card">
                <div className="ml-card-top">
                  <div style={{ minWidth: 0 }}>
                    <div className="ml-card-titlerow">
                      <h3 className="ml-card-title">{l.name}</h3>
                      {l.verified && <span className="ml-verified"><Check size={11} /> Verified</span>}
                    </div>
                    <p className="ml-card-cat">{cat?.icon} {cat?.label}</p>
                  </div>
                </div>
                <p className="ml-card-tag">{l.tagline}</p>
                <div className="ml-card-foot">
                  <Stars rating={l.rating} />
                  <span className="ml-card-reviews">{l.reviews} reviews</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </>
  );
}

function EmptyState({ msg }) {
  return <div className="ml-empty">{msg}</div>;
}

function SubmitModal({ nav, isUS, onClose, onSubmit }) {
  const [f, setF] = useState({ name: "", category: "home", tagline: "" });
  const set = (k) => (e) => setF((s) => ({ ...s, [k]: e.target.value }));
  const cityKey = nav.city ? (isUS ? `US-${nav.state?.code}-${nav.city}` : `${nav.country?.code}-${nav.city}`) : null;
  const canSubmit = f.name.trim() && f.tagline.trim() && cityKey;
  const where = nav.city ? `${nav.city}${isUS ? ", " + nav.state.name : ""}, ${nav.country.name}` : "— navigate to a city first —";

  return (
    <div className="ml-modal-bg" onClick={onClose}>
      <div className="ml-modal" onClick={(e) => e.stopPropagation()}>
        <div className="ml-modal-head">
          <h2 className="ml-modal-title">Add a business</h2>
          <button onClick={onClose} className="ml-icon-btn"><X size={20} /></button>
        </div>
        <div className="ml-modal-body">
          <div className="ml-loc-note"><MapPin size={14} /> {where}</div>
          <label className="ml-field"><span>Business name</span>
            <input className="ml-input" value={f.name} onChange={set("name")} placeholder="e.g. Summit Roofing Co." />
          </label>
          <label className="ml-field"><span>Category</span>
            <select className="ml-input" value={f.category} onChange={set("category")}>
              {CATEGORIES.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
            </select>
          </label>
          <label className="ml-field"><span>One-line description</span>
            <input className="ml-input" value={f.tagline} onChange={set("tagline")} placeholder="What you do, in a sentence." />
          </label>
        </div>
        <div className="ml-modal-foot">
          <button onClick={onClose} className="ml-btn-ghost">Cancel</button>
          <button className="ml-btn-primary" disabled={!canSubmit}
            onClick={() => onSubmit({ id: `u-${Date.now()}`, cityKey, rating: 0, reviews: 0, verified: false, ...f })}>
            Submit listing
          </button>
        </div>
      </div>
    </div>
  );
}

function MLStyle() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
      .ml{
        --bg:#f6f7f9;--card:#ffffff;--ink:#1a1d24;--mute:#5b6270;--faint:#9aa1ad;
        --border:#e7e9ee;--border2:#eef0f4;--accent:#2563eb;--accent-soft:#eef3ff;
        --star:#f5a623;--green:#0ca678;--green-soft:#e6f7f1;
        --font:'Plus Jakarta Sans',system-ui,-apple-system,sans-serif;
        background:var(--bg);color:var(--ink);font-family:var(--font);min-height:100vh;-webkit-font-smoothing:antialiased;
      }
      .ml *{box-sizing:border-box}
      .ml-container{max-width:1120px;margin:0 auto;padding:0 24px}

      .ml-topnav{background:var(--card);border-bottom:1px solid var(--border);position:sticky;top:0;z-index:30}
      .ml-topnav-inner{display:flex;align-items:center;justify-content:space-between;height:64px}
      .ml-logo{background:none;border:none;cursor:pointer;font-family:inherit;font-weight:800;font-size:21px;letter-spacing:-.02em;color:var(--ink);padding:0}
      .ml-logo span{color:var(--accent)}

      .ml-btn-primary{display:inline-flex;align-items:center;justify-content:center;gap:7px;background:var(--accent);color:#fff;font-weight:700;font-size:14px;font-family:inherit;border:none;border-radius:11px;padding:11px 17px;cursor:pointer;transition:background .15s,transform .1s}
      .ml-btn-primary:hover{background:#1d4fd8;transform:translateY(-1px)}
      .ml-btn-primary:disabled{opacity:.4;cursor:not-allowed;transform:none;background:var(--accent)}
      .ml-btn-ghost{background:none;border:none;color:var(--mute);font-weight:600;font-size:14px;font-family:inherit;cursor:pointer;padding:10px 14px}
      .ml-btn-ghost:hover{color:var(--ink)}
      .ml-icon-btn{background:none;border:none;color:var(--faint);cursor:pointer;padding:4px}
      .ml-icon-btn:hover{color:var(--ink)}

      .ml-hero{background:var(--card);border-bottom:1px solid var(--border);padding:52px 0 44px}
      .ml-eyebrow{color:var(--accent);font-weight:700;font-size:13px;letter-spacing:.06em;text-transform:uppercase;margin:0 0 14px}
      .ml-hero-title{font-size:clamp(30px,5vw,48px);line-height:1.08;letter-spacing:-.03em;font-weight:800;margin:0}
      .ml-hero-sub{color:var(--mute);font-size:17px;margin:16px 0 0;max-width:520px}
      .ml-hero-search{display:flex;align-items:center;gap:12px;background:var(--bg);border:1px solid var(--border);border-radius:13px;padding:0 16px;margin-top:26px;max-width:560px}
      .ml-hero-search:focus-within{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-soft)}

      .ml-crumbs{display:flex;flex-wrap:wrap;align-items:center;gap:6px;padding-top:20px}
      .ml-crumb{background:none;border:none;color:var(--mute);font-size:14px;font-weight:600;font-family:inherit;cursor:pointer;padding:2px 4px;border-radius:6px}
      .ml-crumb:hover{color:var(--accent)}
      .ml-crumb-active{color:var(--ink);cursor:default}

      .ml-search{display:flex;align-items:center;gap:12px;background:var(--card);border:1px solid var(--border);border-radius:13px;padding:0 16px}
      .ml-search:focus-within{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-soft)}
      .ml-search-input{flex:1;background:none;border:none;outline:none;color:var(--ink);font-size:15px;font-family:inherit;padding:14px 0}
      .ml-search-input::placeholder{color:var(--faint)}
      .ml-search-clear{background:none;border:none;color:var(--faint);cursor:pointer;padding:4px}

      .ml-country-section{margin-bottom:36px}
      .ml-country-section:last-child{margin-bottom:0}
      .ml-sectionhead{display:flex;align-items:center;justify-content:space-between;margin-bottom:18px}
      .ml-sectionhead-title{display:inline-flex;align-items:center;gap:8px;color:var(--mute);font-weight:700;font-size:13px;text-transform:uppercase;letter-spacing:.05em}
      .ml-sectionhead-extra{font-size:13px;color:var(--faint)}

      .ml-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px}
      .ml-tile{display:flex;align-items:center;gap:12px;background:var(--card);border:1px solid var(--border);border-radius:12px;padding:14px 16px;cursor:pointer;text-align:left;transition:border-color .15s,box-shadow .15s,transform .1s;color:var(--ink);font-family:inherit}
      .ml-tile:hover{border-color:var(--accent);box-shadow:0 4px 14px rgba(37,99,235,.1);transform:translateY(-1px)}
      .ml-tile-flag{font-size:22px;line-height:1}
      .ml-tile-code{width:34px;height:26px;display:grid;place-items:center;background:var(--accent-soft);color:var(--accent);border-radius:6px;font-size:12px;font-weight:700}
      .ml-tile-label{flex:1;font-weight:600;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      .ml-tile-arrow{color:var(--faint);flex-shrink:0}
      .ml-tile:hover .ml-tile-arrow{color:var(--accent)}

      .ml-chips{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:22px}
      .ml-chip{display:inline-flex;align-items:center;gap:6px;background:var(--card);border:1px solid var(--border);color:var(--mute);border-radius:999px;padding:7px 13px;font-size:13px;font-weight:600;font-family:inherit;cursor:pointer;transition:all .12s}
      .ml-chip:hover{border-color:var(--faint);color:var(--ink)}
      .ml-chip-on{background:var(--accent-soft);color:var(--accent);border-color:transparent}

      .ml-listing-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px}
      .ml-card{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:18px;transition:box-shadow .15s,transform .1s;box-shadow:0 1px 3px rgba(20,24,40,.04)}
      .ml-card:hover{box-shadow:0 6px 18px rgba(20,24,40,.09);transform:translateY(-2px)}
      .ml-card-top{display:flex;justify-content:space-between;align-items:flex-start}
      .ml-card-titlerow{display:flex;align-items:center;gap:8px}
      .ml-card-title{font-size:16px;font-weight:700;margin:0;color:var(--ink)}
      .ml-verified{display:inline-flex;align-items:center;gap:3px;font-size:11px;font-weight:700;color:var(--green);background:var(--green-soft);padding:2px 7px;border-radius:999px}
      .ml-card-cat{font-size:12.5px;color:var(--faint);margin:6px 0 0}
      .ml-card-tag{font-size:14px;color:var(--mute);margin:12px 0 0;line-height:1.5}
      .ml-card-foot{display:flex;align-items:center;justify-content:space-between;margin-top:16px;padding-top:14px;border-top:1px solid var(--border2)}
      .ml-card-reviews{font-size:12px;color:var(--faint)}

      .ml-empty{border:1px dashed var(--border);background:var(--card);border-radius:16px;padding:48px 20px;text-align:center;color:var(--mute);font-size:15px}

      .ml-footer{border-top:1px solid var(--border);background:var(--card);margin-top:20px;padding:28px 0}
      .ml-footer-inner{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px}
      .ml-footer-note{color:var(--faint);font-size:13px}

      .ml-modal-bg{position:fixed;inset:0;z-index:50;background:rgba(15,18,28,.5);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;padding:16px}
      .ml-modal{background:var(--card);width:100%;max-width:480px;border-radius:18px;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.25)}
      .ml-modal-head{display:flex;align-items:center;justify-content:space-between;padding:20px;border-bottom:1px solid var(--border)}
      .ml-modal-title{font-size:19px;font-weight:800;margin:0;letter-spacing:-.01em}
      .ml-modal-body{padding:20px;display:grid;gap:16px}
      .ml-modal-foot{display:flex;justify-content:flex-end;gap:10px;padding:16px 20px;border-top:1px solid var(--border)}
      .ml-loc-note{display:inline-flex;align-items:center;gap:7px;background:var(--accent-soft);color:var(--accent);border-radius:9px;padding:9px 13px;font-size:13px;font-weight:600}
      .ml-field>span{display:block;font-size:13px;font-weight:600;color:var(--mute);margin-bottom:7px}
      .ml-input{width:100%;background:var(--card);border:1px solid var(--border);border-radius:10px;padding:11px 13px;color:var(--ink);font-size:14px;font-family:inherit;outline:none}
      .ml-input:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-soft)}

      @media(max-width:640px){.ml-hero{padding:36px 0 30px}.ml-grid{grid-template-columns:repeat(auto-fill,minmax(150px,1fr))}}
    `}</style>
  );
}
