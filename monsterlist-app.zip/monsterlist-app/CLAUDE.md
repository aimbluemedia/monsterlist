# Build guide for Claude Code

This is a Next.js 14 (App Router) + Supabase scaffold for MonsterList, a worldwide
small-business directory. Three UIs are already built and matching; your job is to
wire the backend and expand features. **Search the codebase for `TODO(backend)` —
every integration point is marked.**

## Ground rules
- Keep everything SEO-first: pages under `src/app/[country]/...` MUST stay
  server-rendered. Do not convert them to client components.
- The interactive `/browse` explorer and the three big UI components in
  `src/components/` are client components (they use hooks) — that's fine.
- All colors/typography come from CSS vars in `src/app/globals.css`. Reuse them.

## Recommended build order
1. **Supabase**: create project, run `supabase/schema.sql`, add env vars from `.env.example`.
2. **Seed geography + categories** from `src/data/*.json` into the DB.
3. **`src/lib/data.ts`**: replace each `TODO(backend)` with real Supabase queries.
4. **Pass real data as props** into `HomePage`, `DirectoryBrowse`, `BusinessStorefront`
   (they currently render internal sample data — refactor to accept props).
5. **Auth**: Supabase Auth for two roles — business owners (claim/manage) and reviewers.
6. **Submission flow**: "Add a business" writes with status='pending'; build an admin
   review queue before listings go live (spam control).
7. **Social**: implement fetchers in `src/lib/social/`, set `CRON_SECRET`, verify the
   hourly cron at `/api/cron/social` upserts into `social_posts`.
8. **Stripe**: back the `subscriptions` table; gate `pro`/`featured` features in the UI.
9. **Sitemaps**: paginate `sitemap.ts` with `generateSitemaps()` once businesses exist.

## Tiers
`listing_tier` enum = free | pro | featured. Free = basic listing. Pro = full
storefront (gallery, content, social). Featured = pro + priority placement
(homepage + top of city/category pages).

## URL structure (the SEO backbone)
- `/` homepage
- `/browse` interactive explorer
- `/[country]/[region]/[city]` city listings (US uses region=state; intl 2-tier)
- `/[country]/[region]/[city]/[business]` storefront
- Later: `/category/[cat]/[country]/[region]/[city]` category+location landing pages
