import type { Metadata } from "next";
import "./globals.css";

const SITE = process.env.NEXT_PUBLIC_SITE_URL || "https://monsterlist.org";

export const metadata: Metadata = {
  metadataBase: new URL(SITE),
  title: {
    default: "MonsterList — Find trusted local businesses, anywhere",
    template: "%s · MonsterList",
  },
  description:
    "Browse 1.2M+ small businesses across 249 countries with reviews, photos, content, and social feeds. A directory open to the world.",
  openGraph: { type: "website", siteName: "MonsterList", url: SITE },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
