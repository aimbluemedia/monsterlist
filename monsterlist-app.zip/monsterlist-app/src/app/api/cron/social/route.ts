import { NextResponse } from "next/server";
// import { aggregateForBusiness } from "@/lib/social";

// Scheduled by Vercel Cron (see vercel.json). Refreshes cached social posts.
// Protect with a secret so only the cron can call it.
export async function GET(req: Request) {
  const auth = req.headers.get("authorization");
  if (auth !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ ok: false }, { status: 401 });
  }
  // TODO(backend):
  // 1. select businesses with social handles + a pro/featured tier
  // 2. for each: const posts = await aggregateForBusiness(handles)
  // 3. upsert posts into social_posts table
  return NextResponse.json({ ok: true, refreshed: 0 });
}
