import DirectoryBrowse from "@/components/DirectoryBrowse";

export const metadata = { title: "Browse businesses by location" };

// Interactive client-side drill-down (Country -> State -> City -> Listings).
// The SEO-indexed versions of each place live at the static routes below
// (e.g. /us/arizona/phoenix). This browse page is the app-like explorer.
export default function Page() {
  return <DirectoryBrowse />;
}
