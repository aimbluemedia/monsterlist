import type { MetadataRoute } from "next";
import { COUNTRIES, US_STATES, US_CITIES, COUNTRY_CITIES, slug } from "@/lib/data";

const SITE = process.env.NEXT_PUBLIC_SITE_URL || "https://monsterlist.org";

// NOTE: With millions of URLs you must PAGINATE the sitemap (Next supports
// generateSitemaps()). This version lists geography pages to get you started.
// TODO(backend): add per-business URLs, paginate at 50k entries each.
export default function sitemap(): MetadataRoute.Sitemap {
  const entries: MetadataRoute.Sitemap = [{ url: SITE, changeFrequency: "daily", priority: 1 }];

  for (const c of COUNTRIES) {
    const cc = c.code.toLowerCase();
    entries.push({ url: `${SITE}/${cc}`, changeFrequency: "weekly", priority: 0.6 });

    if (c.code === "US") {
      for (const s of US_STATES) {
        const region = slug(s.name);
        entries.push({ url: `${SITE}/us/${region}`, changeFrequency: "weekly", priority: 0.5 });
        for (const city of US_CITIES[s.code] || []) {
          entries.push({ url: `${SITE}/us/${region}/${slug(city)}`, changeFrequency: "weekly", priority: 0.5 });
        }
      }
    } else {
      for (const city of COUNTRY_CITIES[c.code] || []) {
        entries.push({ url: `${SITE}/${cc}/_/${slug(city)}`, changeFrequency: "weekly", priority: 0.5 });
      }
    }
  }
  return entries;
}
