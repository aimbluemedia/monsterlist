# MonsterList

A worldwide small-business directory — SEO-first, built to be indexed by Google
and AI crawlers. Next.js (App Router) + Supabase.

## What's in this scaffold

Three finished, matching UIs (clean light theme) plus the SEO plumbing:

- **Homepage** (`/`) — hero search, top categories, premium members, new members,
  top locations, content promos, social promos, CTA band, footer.
- **Browse** (`/browse`) — interactive drill-down:
  US → State → City → Listings, and Country → City → Listings.
- **City page** (`/[country]/[region]/[city]`) — server-rendered listings, SEO metadata,
  `ItemList` + `BreadcrumbList` JSON-LD.
- **Business storefront** (`/[country]/[region]/[city]/[business]`) — server-rendered,
  `LocalBusiness` JSON-LD, tabs for Overview / Services / Products / Articles /
  Videos / Photos / Reviews, plus a social feed (FB, IG, TikTok, Reddit, Pinterest, YouTube).

SEO: `robots.ts` (welcomes GPTBot, ClaudeBot, PerplexityBot, Google-Extended),
`sitemap.ts` (geography URLs; paginate for businesses), per-page metadata + JSON-LD.

Social: `src/lib/social/` fetchers (one per platform, stubbed) + an hourly
Vercel Cron (`/api/cron/social`) that refreshes cached posts into the DB.

## Getting started

```bash
npm install
cp .env.example .env.local   # fill in Supabase + social API keys
npm run dev                  # http://localhost:3000
```

The site renders immediately using SAMPLE data (see `src/lib/data.ts`) so you can
work on UI before the backend exists.

## Wiring the backend (do these in order)

1. Create a Supabase project. Run `supabase/schema.sql` in the SQL editor.
2. Add `NEXT_PUBLIC_SUPABASE_URL` / `NEXT_PUBLIC_SUPABASE_ANON_KEY` / `SUPABASE_SERVICE_ROLE_KEY`.
3. Replace the `TODO(backend)` bodies in `src/lib/data.ts` with real Supabase queries.
4. Pass fetched records as props into the components (they currently self-render sample data).
5. Seed `countries`, `regions`, `cities`, `categories` from `src/data/*.json`.
6. Enable the social fetchers in `src/lib/social/` and set `CRON_SECRET`.
7. Add Stripe for the `subscriptions` table (paid tiers: free / pro / featured).

## Search for `TODO(backend)` to find every integration point.

## Tiers (already in schema)
- **free** — name, category, location, basic contact, appears in search.
- **pro** — full storefront (gallery, content, social feed, verified).
- **featured** — pro + priority placement (homepage + top of city/category).
