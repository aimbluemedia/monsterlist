// ---------------------------------------------------------------------------
// Social feed aggregation.
//
// Each platform is fetched server-side on a schedule (e.g. hourly cron / Vercel
// Cron), the posts are stored in your DB, and the storefront/homepage render
// them from the DB — never fetch live in the browser (bad for SEO + perf).
//
// Fill in each fetcher as you enable that platform's API. Tokens live in .env.
// ---------------------------------------------------------------------------
export type SocialPost = {
  platform: "facebook" | "instagram" | "tiktok" | "reddit" | "pinterest" | "youtube";
  handle: string; text: string; url: string;
  likes: number; comments: number; mediaUrl?: string; postedAt: string;
};

// TODO: YouTube Data API v3 — search.list / playlistItems by channelId
export async function fetchYouTube(channelId: string): Promise<SocialPost[]> { return []; }

// TODO: Meta Graph API — /{ig-user-id}/media  (requires app review)
export async function fetchInstagram(igUserId: string): Promise<SocialPost[]> { return []; }

// TODO: Meta Graph API — /{page-id}/posts
export async function fetchFacebook(pageId: string): Promise<SocialPost[]> { return []; }

// TODO: TikTok Display API — /v2/video/list/
export async function fetchTikTok(openId: string): Promise<SocialPost[]> { return []; }

// TODO: Pinterest API — /v5/pins
export async function fetchPinterest(username: string): Promise<SocialPost[]> { return []; }

// Reddit has a public JSON endpoint: https://www.reddit.com/user/{user}/submitted.json
export async function fetchReddit(username: string): Promise<SocialPost[]> {
  // TODO: fetch + map to SocialPost[]. Respect rate limits / set a User-Agent.
  return [];
}

export async function aggregateForBusiness(handles: Partial<Record<SocialPost["platform"], string>>) {
  const jobs: Promise<SocialPost[]>[] = [];
  if (handles.youtube) jobs.push(fetchYouTube(handles.youtube));
  if (handles.instagram) jobs.push(fetchInstagram(handles.instagram));
  if (handles.facebook) jobs.push(fetchFacebook(handles.facebook));
  if (handles.tiktok) jobs.push(fetchTikTok(handles.tiktok));
  if (handles.pinterest) jobs.push(fetchPinterest(handles.pinterest));
  if (handles.reddit) jobs.push(fetchReddit(handles.reddit));
  const results = await Promise.allSettled(jobs);
  return results.flatMap((r) => (r.status === "fulfilled" ? r.value : []))
    .sort((a, b) => +new Date(b.postedAt) - +new Date(a.postedAt));
}
