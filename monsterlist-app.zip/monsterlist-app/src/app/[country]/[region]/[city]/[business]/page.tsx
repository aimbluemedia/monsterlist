import type { Metadata } from "next";
import BusinessStorefront from "@/components/BusinessStorefront";
import { JsonLd, localBusinessJsonLd, breadcrumbJsonLd } from "@/lib/seo";
import { getBusiness } from "@/lib/data";

type Params = { country: string; region: string; city: string; business: string };

// TODO(backend): resolve cityKey properly from country/region/city slugs.
function cityKeyFromParams(p: Params) {
  // US -> US-STATECODE-City ; intl -> COUNTRYCODE-City. Placeholder for now.
  return `${p.country.toUpperCase()}-${p.region}-${p.city}`;
}

export async function generateMetadata({ params }: { params: Params }): Promise<Metadata> {
  const b = await getBusiness(cityKeyFromParams(params), params.business);
  const cityName = params.city.replace(/-/g, " ");
  const title = b ? `${b.name} — ${cityName}` : "Business";
  const description = b?.tagline;
  const path = `/${params.country}/${params.region}/${params.city}/${params.business}`;
  return {
    title,
    description,
    alternates: { canonical: path },
    openGraph: { title, description, url: path, type: "profile" },
  };
}

export default async function Page({ params }: { params: Params }) {
  const b = await getBusiness(cityKeyFromParams(params), params.business);
  const path = `/${params.country}/${params.region}/${params.city}/${params.business}`;
  const cityName = params.city.replace(/-/g, " ");

  const ld = localBusinessJsonLd({
    name: b?.name ?? "Business",
    description: b?.tagline,
    city: cityName,
    countryCode: params.country.toUpperCase(),
    rating: b?.rating,
    reviewCount: b?.reviews,
    path,
  });
  const crumbs = breadcrumbJsonLd([
    { name: "Home", path: "/" },
    { name: params.country.toUpperCase(), path: `/${params.country}` },
    { name: params.region, path: `/${params.country}/${params.region}` },
    { name: cityName, path: `/${params.country}/${params.region}/${params.city}` },
    { name: b?.name ?? "Business", path },
  ]);

  return (
    <>
      <JsonLd data={ld} />
      <JsonLd data={crumbs} />
      {/* TODO(backend): pass `b` (full record) into the storefront as props.
          The component currently renders sample data internally. */}
      <BusinessStorefront />
    </>
  );
}

// TODO(backend): generateStaticParams() to pre-build top businesses for speed + indexing.
