-- ===========================================================================
-- MonsterList schema (Supabase / Postgres)
-- Run in the Supabase SQL editor, or via `supabase db push`.
-- ===========================================================================

-- ---- Geography ----------------------------------------------------------
create table countries (
  code        char(2) primary key,        -- ISO alpha-2
  name        text not null,
  flag        text,
  is_popular  boolean default false,       -- drives "Popular countries" section
  popularity  int default 0
);

create table regions (                      -- US states (tier for US only)
  id          bigserial primary key,
  country_code char(2) references countries(code),
  code        text,                         -- e.g. AZ
  name        text not null,
  slug        text not null,
  is_popular  boolean default false,
  unique (country_code, slug)
);

create table cities (
  id          bigserial primary key,
  country_code char(2) references countries(code),
  region_id   bigint references regions(id),  -- null for 2-tier (non-US) countries
  name        text not null,
  slug        text not null,
  is_popular  boolean default false,
  listing_count int default 0,
  unique (country_code, region_id, slug)
);

-- ---- Categories ---------------------------------------------------------
create table categories (
  id    text primary key,   -- e.g. 'roofing'
  label text not null,
  icon  text,
  popularity int default 0
);

-- ---- Businesses ---------------------------------------------------------
create type listing_tier as enum ('free', 'pro', 'featured');

create table businesses (
  id            uuid primary key default gen_random_uuid(),
  owner_id      uuid,                        -- auth.users; null until claimed
  name          text not null,
  slug          text not null,
  category_id   text references categories(id),
  city_id       bigint references cities(id),
  tier          listing_tier default 'free',
  status        text default 'pending',      -- pending | live | rejected
  verified      boolean default false,
  tagline       text,
  description    text,
  founded       int,
  phone         text,
  website       text,
  email         text,
  address       text,
  lat           double precision,
  lng           double precision,
  hours         jsonb,                       -- [{d,h,open}]
  credentials   text[],
  social        jsonb,                       -- {facebook, instagram, tiktok, ...}
  rating        numeric(2,1) default 0,
  review_count  int default 0,
  created_at    timestamptz default now(),
  unique (city_id, slug)
);
create index on businesses (city_id);
create index on businesses (category_id);
create index on businesses (tier);
create index on businesses using gin (to_tsvector('english', name || ' ' || coalesce(tagline,'')));

-- ---- Content (articles / videos / products / services) ------------------
create table articles (
  id uuid primary key default gen_random_uuid(),
  business_id uuid references businesses(id) on delete cascade,
  title text not null, slug text not null, excerpt text, body text,
  cover_url text, read_minutes int, published_at timestamptz default now()
);
create table videos (
  id uuid primary key default gen_random_uuid(),
  business_id uuid references businesses(id) on delete cascade,
  title text not null, url text, thumb_url text, duration text, views int
);
create table products (
  id uuid primary key default gen_random_uuid(),
  business_id uuid references businesses(id) on delete cascade,
  name text not null, price text, note text, image_url text
);
create table services (
  id uuid primary key default gen_random_uuid(),
  business_id uuid references businesses(id) on delete cascade,
  name text not null, description text, price text
);

-- ---- Gallery + reviews --------------------------------------------------
create table gallery (
  id uuid primary key default gen_random_uuid(),
  business_id uuid references businesses(id) on delete cascade,
  url text not null, label text, sort int default 0
);
create table reviews (
  id uuid primary key default gen_random_uuid(),
  business_id uuid references businesses(id) on delete cascade,
  author_id uuid, author_name text,
  rating int check (rating between 1 and 5),
  body text, created_at timestamptz default now()
);

-- ---- Cached social posts ------------------------------------------------
create table social_posts (
  id uuid primary key default gen_random_uuid(),
  business_id uuid references businesses(id) on delete cascade,
  platform text not null,      -- facebook|instagram|tiktok|reddit|pinterest|youtube
  handle text, text text, url text, media_url text,
  likes int, comments int, posted_at timestamptz,
  fetched_at timestamptz default now()
);
create index on social_posts (business_id, posted_at desc);

-- ---- Subscriptions (paid tiers) ----------------------------------------
create table subscriptions (
  id uuid primary key default gen_random_uuid(),
  business_id uuid references businesses(id) on delete cascade,
  tier listing_tier not null,
  status text default 'active',      -- active | past_due | canceled
  stripe_customer_id text,
  stripe_subscription_id text,
  current_period_end timestamptz
);

-- ---- Row Level Security (enable + add policies before launch) -----------
-- alter table businesses enable row level security;
-- create policy "public can read live businesses" on businesses for select using (status = 'live');
-- create policy "owners manage their business" on businesses for all using (auth.uid() = owner_id);
