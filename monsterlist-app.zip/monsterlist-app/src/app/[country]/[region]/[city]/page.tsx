import type { Metadata } from "next";
import Link from "next/link";
import { JsonLd, breadcrumbJsonLd, itemListJsonLd } from "@/lib/seo";
import { getListings, CATEGORIES, slug } from "@/lib/data";

type Params = { country: string; region: string; city: string };

export async function generateMetadata({ params }: { params: Params }): Promise<Metadata> {
  const cityName = titleCase(params.city);
  const regionName = titleCase(params.region);
  const title = `Businesses in ${cityName}, ${regionName}`;
  return {
    title,
    description: `Find and compare trusted local businesses in ${cityName}. Reviews, photos, and contact info on MonsterList.`,
    alternates: { canonical: `/${params.country}/${params.region}/${params.city}` },
  };
}

const titleCase = (s: string) => s.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

export default async function Page({ params }: { params: Params }) {
  const cityKey = `${params.country.toUpperCase()}-${params.region}-${params.city}`;
  const listings = await getListings(cityKey);
  const cityName = titleCase(params.city);
  const path = `/${params.country}/${params.region}/${params.city}`;

  const crumbs = breadcrumbJsonLd([
    { name: "Home", path: "/" },
    { name: params.country.toUpperCase(), path: `/${params.country}` },
    { name: titleCase(params.region), path: `/${params.country}/${params.region}` },
    { name: cityName, path },
  ]);
  const itemList = itemListJsonLd(listings.map((l) => l.name), path);

  return (
    <>
      <JsonLd data={crumbs} />
      <JsonLd data={itemList} />
      <main style={{ maxWidth: 1080, margin: "0 auto", padding: "32px 24px" }}>
        <nav style={{ fontSize: 13, color: "var(--faint)", marginBottom: 16 }}>
          <Link href="/">Home</Link> › <Link href={`/${params.country}`}>{params.country.toUpperCase()}</Link> ›{" "}
          <Link href={`/${params.country}/${params.region}`}>{titleCase(params.region)}</Link> › {cityName}
        </nav>
        <h1 style={{ fontSize: 30, fontWeight: 800, letterSpacing: "-.02em", margin: "0 0 6px" }}>
          Businesses in {cityName}
        </h1>
        <p style={{ color: "var(--mute)", margin: "0 0 26px" }}>{listings.length} listings</p>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(280px,1fr))", gap: 14 }}>
          {listings.map((l) => {
            const cat = CATEGORIES.find((c) => c.id === l.category);
            return (
              <Link key={l.id} href={`${path}/${l.slug}`}
                style={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 16, padding: 18, boxShadow: "0 1px 3px rgba(20,24,40,.04)", display: "block" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <strong style={{ fontSize: 16 }}>{l.name}</strong>
                  {l.verified && <span style={{ fontSize: 11, fontWeight: 700, color: "var(--green)", background: "var(--green-soft)", padding: "2px 7px", borderRadius: 999 }}>Verified</span>}
                </div>
                <p style={{ fontSize: 12.5, color: "var(--faint)", margin: "6px 0 0" }}>{cat?.icon} {cat?.label}</p>
                <p style={{ fontSize: 14, color: "var(--mute)", margin: "12px 0 0", lineHeight: 1.5 }}>{l.tagline}</p>
                <div style={{ marginTop: 14, paddingTop: 12, borderTop: "1px solid var(--border2)", fontSize: 13, color: "var(--mute)" }}>
                  ★ {l.rating} · {l.reviews} reviews
                </div>
              </Link>
            );
          })}
        </div>
      </main>
    </>
  );
}

// TODO(backend): generateStaticParams() for top cities; enable ISR revalidate.
