// ---------------------------------------------------------------------------
// SEO helpers: JSON-LD builders + shared metadata utilities.
// These emit the structured data that Google + AI crawlers (GPTBot, ClaudeBot,
// PerplexityBot, Google-Extended) read to understand each page.
// ---------------------------------------------------------------------------
const SITE = process.env.NEXT_PUBLIC_SITE_URL || "https://monsterlist.org";

export function localBusinessJsonLd(b: {
  name: string; description?: string; url?: string; telephone?: string;
  street?: string; city: string; region?: string; regionCode?: string; countryCode: string;
  lat?: number; lng?: number; rating?: number; reviewCount?: number; path: string;
}) {
  return {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    name: b.name,
    description: b.description,
    "@id": `${SITE}${b.path}`,
    url: b.url,
    telephone: b.telephone,
    priceRange: "$$",
    address: {
      "@type": "PostalAddress",
      streetAddress: b.street,
      addressLocality: b.city,
      addressRegion: b.regionCode || b.region,
      addressCountry: b.countryCode,
    },
    ...(b.lat && b.lng ? { geo: { "@type": "GeoCoordinates", latitude: b.lat, longitude: b.lng } } : {}),
    ...(b.rating ? { aggregateRating: { "@type": "AggregateRating", ratingValue: b.rating, reviewCount: b.reviewCount } } : {}),
  };
}

export function breadcrumbJsonLd(items: { name: string; path: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((it, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: it.name,
      item: `${SITE}${it.path}`,
    })),
  };
}

export function itemListJsonLd(names: string[], basePath: string) {
  return {
    "@context": "https://schema.org",
    "@type": "ItemList",
    itemListElement: names.map((n, i) => ({ "@type": "ListItem", position: i + 1, name: n })),
  };
}

export function JsonLd({ data }: { data: object }) {
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }} />;
}
