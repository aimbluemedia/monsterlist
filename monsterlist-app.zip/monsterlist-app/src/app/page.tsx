import HomePage from "@/components/HomePage";

// The homepage is a marketing/discovery page. In production, fetch the
// premium members, new members, top categories/locations, and promos
// server-side here and pass them as props for SEO + freshness.
// TODO(backend): const data = await getHomepageData();
export default function Page() {
  return <HomePage />;
}
