"use client";
import React, { useState } from "react";
import {
  MapPin, Star, Check, Phone, Globe, Mail, Clock, Share2, Flag,
  ChevronRight, Camera, MessageSquare, Award, FileText, PlayCircle,
  ShoppingBag, Wrench, ExternalLink, Heart, MessageCircle, Repeat2,
  Facebook, Instagram, Linkedin, Youtube, ChevronLeft, BadgeCheck
} from "lucide-react";

const BUSINESS = {
  name: "Summit Roofing Co.",
  category: "Roofing",
  verified: true,
  rating: 4.8,
  reviewCount: 214,
  responseTime: "Typically replies within 1 hour",
  founded: 2009,
  description:
    "Summit Roofing Co. has protected homes and businesses across the Valley for over 15 years. We specialize in tile, shingle, and flat-roof systems built to handle Arizona's brutal summers. Family-owned, fully licensed and insured, and known for showing up on time and finishing clean.",
  location: { city: "Phoenix", state: "Arizona", stateCode: "AZ", country: "United States", countryCode: "US", address: "2140 E Camelback Rd, Phoenix, AZ 85016", lat: 33.509, lng: -112.03 },
  contact: { phone: "(602) 555-0142", website: "summitroofingaz.com", email: "hello@summitroofingaz.com" },
  hours: [
    { d: "Monday", h: "7:00 AM – 6:00 PM", open: true },
    { d: "Tuesday", h: "7:00 AM – 6:00 PM", open: true },
    { d: "Wednesday", h: "7:00 AM – 6:00 PM", open: true },
    { d: "Thursday", h: "7:00 AM – 6:00 PM", open: true },
    { d: "Friday", h: "7:00 AM – 6:00 PM", open: true },
    { d: "Saturday", h: "8:00 AM – 2:00 PM", open: true },
    { d: "Sunday", h: "Closed", open: false },
  ],
  credentials: ["Licensed ROC #284401", "Fully Insured", "GAF Certified", "BBB A+ Rated"],
  social: { facebook: "#", instagram: "#", linkedin: "#", youtube: "#" },
  gallery: [
    { hue: 205, label: "Tile roof — Scottsdale" },
    { hue: 25, label: "Shingle replacement — Tempe" },
    { hue: 152, label: "Flat roof — Downtown" },
    { hue: 340, label: "Storm repair — Mesa" },
    { hue: 45, label: "Gutter install — Chandler" },
    { hue: 265, label: "Inspection — Gilbert" },
  ],
  // ---- CONTENT ----
  articles: [
    { title: "5 Signs Your Roof Needs Replacing Before Monsoon Season", date: "Jun 12, 2026", read: "4 min read", excerpt: "Arizona summers punish roofing systems. Here's how to spot trouble before the first big storm hits.", hue: 205 },
    { title: "Tile vs. Shingle: Which Roof Lasts Longer in the Desert?", date: "May 28, 2026", read: "6 min read", excerpt: "A side-by-side breakdown of cost, lifespan, and heat performance for Phoenix homeowners.", hue: 30 },
    { title: "What Roof Insurance Actually Covers After a Storm", date: "May 3, 2026", read: "5 min read", excerpt: "Filing a claim? Understand what your policy will and won't pay for before you call.", hue: 152 },
  ],
  videos: [
    { title: "Full Tile Roof Replacement — Start to Finish", duration: "8:42", views: "12K views", hue: 205 },
    { title: "How We Inspect a Roof (What We Look For)", duration: "5:15", views: "4.3K views", hue: 340 },
    { title: "Storm Damage Repair Timelapse", duration: "3:08", views: "9.1K views", hue: 45 },
  ],
  products: [
    { name: "GAF Timberline HDZ Shingles", price: "From $4.20/sq ft", note: "Installed", hue: 25 },
    { name: "Boral Concrete Roof Tile", price: "From $6.80/sq ft", note: "Installed", hue: 205 },
    { name: "Seamless Gutter System", price: "From $9/linear ft", note: "Aluminum, 20+ colors", hue: 152 },
    { name: "Roof Inspection Report", price: "Free", note: "Same-week scheduling", hue: 265 },
  ],
  services: [
    { name: "Roof Replacement", desc: "Full tear-off and re-roof for tile, shingle, and flat systems.", price: "Quote" },
    { name: "Leak Repair", desc: "Same-day emergency leak detection and patching.", price: "From $250" },
    { name: "Free Inspection", desc: "22-point roof health check with photo report.", price: "Free" },
    { name: "Gutter Installation", desc: "Seamless aluminum gutters and guards.", price: "From $9/ft" },
    { name: "Storm Damage Repair", desc: "Insurance-claim assistance and rapid response.", price: "Quote" },
    { name: "Maintenance Plan", desc: "Annual inspection + priority scheduling.", price: "$180/yr" },
  ],
  socialPosts: [
    { platform: "instagram", handle: "@summitroofingaz", time: "2d", text: "Fresh tile install in Scottsdale ☀️ Swipe to see the before. #phoenixroofing", likes: 342, comments: 18, hue: 205 },
    { platform: "youtube", handle: "Summit Roofing Co.", time: "5d", text: "New video: Full tile roof replacement start to finish", likes: 891, comments: 64, hue: 340 },
    { platform: "tiktok", handle: "@summitroofs", time: "1w", text: "POV: your roof survives its first monsoon 🌧️ #rooftok #arizona", likes: 12400, comments: 210, hue: 300 },
    { platform: "facebook", handle: "Summit Roofing Co.", time: "1w", text: "We're now booking free inspections for July — comment or DM to grab a slot.", likes: 156, comments: 42, hue: 220 },
    { platform: "reddit", handle: "u/summitroofing", time: "2w", text: "AMA: 15 years roofing in the Phoenix heat — ask me anything about tile vs shingle", likes: 508, comments: 176, hue: 20 },
    { platform: "pinterest", handle: "Summit Roofing", time: "3w", text: "Desert-modern roofline inspiration board — 40 pins", likes: 89, comments: 4, hue: 350 },
  ],
  reviews: [
    { name: "Jordan M.", rating: 5, date: "2 weeks ago", text: "Replaced our whole roof in two days. Crew was professional, cleaned up every nail, and the price matched the quote exactly." },
    { name: "Priya K.", rating: 5, date: "1 month ago", text: "Found a leak during monsoon season and they came out same day. Fair, fast, and honest about what actually needed fixing." },
    { name: "Dave R.", rating: 4, date: "2 months ago", text: "Solid work on our tile roof. Took a day longer than estimated but the quality was worth it." },
  ],
  ratingBreakdown: [{ s: 5, pct: 82 }, { s: 4, pct: 12 }, { s: 3, pct: 4 }, { s: 2, pct: 1 }, { s: 1, pct: 1 }],
};

const PLATFORMS = {
  facebook:  { label: "Facebook",  color: "#1877f2", Icon: Facebook },
  instagram: { label: "Instagram", color: "#e1306c", Icon: Instagram },
  tiktok:    { label: "TikTok",    color: "#010101", Icon: TikTokIcon },
  reddit:    { label: "Reddit",    color: "#ff4500", Icon: RedditIcon },
  pinterest: { label: "Pinterest", color: "#e60023", Icon: PinterestIcon },
  youtube:   { label: "YouTube",   color: "#ff0000", Icon: Youtube },
};

function buildJsonLd(b) {
  return {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    name: b.name, description: b.description,
    "@id": `https://monsterlist.org/us/${b.location.state.toLowerCase()}/${b.location.city.toLowerCase()}/summit-roofing`,
    url: `https://${b.contact.website}`, telephone: b.contact.phone, priceRange: "$$",
    address: { "@type": "PostalAddress", streetAddress: b.location.address, addressLocality: b.location.city, addressRegion: b.location.stateCode, addressCountry: b.location.countryCode },
    geo: { "@type": "GeoCoordinates", latitude: b.location.lat, longitude: b.location.lng },
    aggregateRating: { "@type": "AggregateRating", ratingValue: b.rating, reviewCount: b.reviewCount },
    foundingDate: String(b.founded),
  };
}

function Stars({ rating, size = 16 }) {
  return (
    <span style={{ display: "inline-flex", gap: 1 }}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Star key={i} size={size} fill={i <= Math.round(rating) ? "var(--star)" : "none"} strokeWidth={i <= Math.round(rating) ? 0 : 1.5} style={{ color: i <= Math.round(rating) ? "var(--star)" : "var(--border)" }} />
      ))}
    </span>
  );
}

const imgBg = (hue) => ({ background: `linear-gradient(135deg, hsl(${hue} 60% 62%), hsl(${hue} 55% 48%))` });
const fmt = (n) => n >= 1000 ? (n / 1000).toFixed(n >= 10000 ? 0 : 1) + "K" : n;

export default function BusinessStorefront() {
  const b = BUSINESS;
  const [tab, setTab] = useState("about");
  const [lightbox, setLightbox] = useState(null);

  const TABS = [
    { id: "about", label: "Overview" },
    { id: "services", label: "Services" },
    { id: "products", label: "Products" },
    { id: "articles", label: "Articles" },
    { id: "videos", label: "Videos" },
    { id: "photos", label: "Photos" },
    { id: "reviews", label: "Reviews" },
  ];

  return (
    <div className="sf">
      <SFStyle />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(buildJsonLd(b)) }} />

      <nav className="sf-topnav">
        <div className="sf-container sf-topnav-inner">
          <a href="#" className="sf-logo">Monster<span>List</span></a>
          <div className="sf-topnav-actions">
            <a href="#" className="sf-topnav-link">Browse</a>
            <a href="#" className="sf-topnav-link">Add a business</a>
          </div>
        </div>
      </nav>

      <div className="sf-container">
        <nav className="sf-crumbs" aria-label="Breadcrumb">
          <a href="#">Home</a><ChevronRight size={13} /><a href="#">United States</a><ChevronRight size={13} />
          <a href="#">Arizona</a><ChevronRight size={13} /><a href="#">Phoenix</a><ChevronRight size={13} />
          <a href="#">Roofing</a><ChevronRight size={13} /><span className="sf-crumb-current">{b.name}</span>
        </nav>
      </div>

      <div className="sf-container">
        <header className="sf-header">
          <div className="sf-logo-badge">{b.name.charAt(0)}</div>
          <div className="sf-header-body">
            <div className="sf-title-row">
              <h1 className="sf-name">{b.name}</h1>
              {b.verified && <span className="sf-verified"><BadgeCheck size={16} /> Verified</span>}
            </div>
            <div className="sf-meta">
              <span className="sf-cat">{b.category}</span><span className="sf-dot" />
              <span className="sf-metaitem"><MapPin size={14} /> {b.location.city}, {b.location.stateCode}</span>
              <span className="sf-dot" /><span className="sf-metaitem">Since {b.founded}</span>
            </div>
            <div className="sf-rating-row">
              <Stars rating={b.rating} /><strong>{b.rating.toFixed(1)}</strong>
              <a href="#" className="sf-reviewlink" onClick={(e) => { e.preventDefault(); setTab("reviews"); }}>{b.reviewCount} reviews</a>
            </div>
          </div>
          <div className="sf-header-cta">
            <button className="sf-btn-primary"><Phone size={17} /> Contact</button>
            <button className="sf-btn-icon"><Share2 size={17} /></button>
          </div>
        </header>

        <div className="sf-layout">
          <main className="sf-main">
            <div className="sf-tabs">
              {TABS.map((t) => (
                <button key={t.id} className={`sf-tab ${tab === t.id ? "sf-tab-on" : ""}`} onClick={() => setTab(t.id)}>{t.label}</button>
              ))}
            </div>

            {tab === "about" && (
              <div className="sf-panel-card sf-fade">
                <p className="sf-desc">{b.description}</p>
                <h3 className="sf-h3"><Award size={17} /> Credentials & licenses</h3>
                <div className="sf-badges">{b.credentials.map((c) => <span key={c} className="sf-badge"><Check size={14} /> {c}</span>)}</div>
                <h3 className="sf-h3"><Camera size={17} /> Recent work</h3>
                <div className="sf-strip">
                  {b.gallery.slice(0, 4).map((g, i) => (
                    <button key={i} className="sf-strip-img" style={imgBg(g.hue)} onClick={() => { setTab("photos"); setLightbox(i); }} aria-label={g.label} />
                  ))}
                </div>
              </div>
            )}

            {tab === "services" && (
              <div className="sf-panel-card sf-fade">
                <h3 className="sf-h3"><Wrench size={17} /> Services offered</h3>
                <div className="sf-svc-list">
                  {b.services.map((s) => (
                    <div key={s.name} className="sf-svc">
                      <div className="sf-svc-body">
                        <strong>{s.name}</strong>
                        <p>{s.desc}</p>
                      </div>
                      <span className="sf-svc-price">{s.price}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {tab === "products" && (
              <div className="sf-panel-card sf-fade">
                <h3 className="sf-h3"><ShoppingBag size={17} /> Products & pricing</h3>
                <div className="sf-products">
                  {b.products.map((p) => (
                    <div key={p.name} className="sf-product">
                      <div className="sf-product-img" style={imgBg(p.hue)} />
                      <div className="sf-product-info">
                        <strong>{p.name}</strong>
                        <span className="sf-product-note">{p.note}</span>
                        <span className="sf-product-price">{p.price}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {tab === "articles" && (
              <div className="sf-panel-card sf-fade">
                <h3 className="sf-h3"><FileText size={17} /> Articles & guides</h3>
                <div className="sf-articles">
                  {b.articles.map((a) => (
                    <a key={a.title} href="#" className="sf-article">
                      <div className="sf-article-thumb" style={imgBg(a.hue)} />
                      <div className="sf-article-body">
                        <h4>{a.title}</h4>
                        <p>{a.excerpt}</p>
                        <span className="sf-article-meta">{a.date} · {a.read}</span>
                      </div>
                    </a>
                  ))}
                </div>
              </div>
            )}

            {tab === "videos" && (
              <div className="sf-panel-card sf-fade">
                <h3 className="sf-h3"><PlayCircle size={17} /> Videos</h3>
                <div className="sf-videos">
                  {b.videos.map((v) => (
                    <a key={v.title} href="#" className="sf-video">
                      <div className="sf-video-thumb" style={imgBg(v.hue)}>
                        <PlayCircle size={44} className="sf-play" />
                        <span className="sf-video-dur">{v.duration}</span>
                      </div>
                      <div className="sf-video-info">
                        <strong>{v.title}</strong>
                        <span className="sf-muted">{v.views}</span>
                      </div>
                    </a>
                  ))}
                </div>
              </div>
            )}

            {tab === "photos" && (
              <div className="sf-panel-card sf-fade">
                <div className="sf-gallery">
                  {b.gallery.map((g, i) => (
                    <button key={i} className="sf-gcard" style={imgBg(g.hue)} onClick={() => setLightbox(i)}>
                      <span className="sf-gcard-label">{g.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {tab === "reviews" && (
              <div className="sf-panel-card sf-fade">
                <div className="sf-review-top">
                  <div className="sf-review-score">
                    <span className="sf-score-num">{b.rating.toFixed(1)}</span>
                    <Stars rating={b.rating} size={18} /><span className="sf-muted">{b.reviewCount} reviews</span>
                  </div>
                  <div className="sf-review-bars">
                    {b.ratingBreakdown.map((r) => (
                      <div key={r.s} className="sf-barrow">
                        <span>{r.s}</span><Star size={12} fill="var(--star)" strokeWidth={0} style={{ color: "var(--star)" }} />
                        <div className="sf-bar"><div className="sf-bar-fill" style={{ width: `${r.pct}%` }} /></div>
                        <span className="sf-muted sf-barpct">{r.pct}%</span>
                      </div>
                    ))}
                  </div>
                </div>
                <button className="sf-btn-outline sf-write"><MessageSquare size={16} /> Write a review</button>
                <div className="sf-reviews">
                  {b.reviews.map((r, i) => (
                    <article key={i} className="sf-review">
                      <div className="sf-review-head">
                        <div className="sf-avatar">{r.name.charAt(0)}</div>
                        <div><strong>{r.name}</strong>
                          <div className="sf-review-sub"><Stars rating={r.rating} size={13} /> <span className="sf-muted">{r.date}</span></div>
                        </div>
                      </div>
                      <p className="sf-review-text">{r.text}</p>
                    </article>
                  ))}
                </div>
              </div>
            )}

            {/* ---- SOCIAL FEED (always visible below tab content) ---- */}
            <div className="sf-social-section">
              <div className="sf-social-head">
                <h3 className="sf-h3" style={{ margin: 0 }}><Share2 size={17} /> On social media</h3>
                <div className="sf-social-follow">
                  {Object.entries(PLATFORMS).map(([key, p]) => (
                    <a key={key} href="#" className="sf-follow-chip" style={{ "--pc": p.color }} aria-label={p.label}>
                      <p.Icon size={15} />
                    </a>
                  ))}
                </div>
              </div>
              <div className="sf-social-grid">
                {b.socialPosts.map((post, i) => {
                  const p = PLATFORMS[post.platform];
                  return (
                    <a key={i} href="#" className="sf-post">
                      <div className="sf-post-head">
                        <span className="sf-post-platform" style={{ background: p.color }}><p.Icon size={13} /></span>
                        <div className="sf-post-id">
                          <strong>{post.handle}</strong>
                          <span className="sf-muted">{p.label} · {post.time}</span>
                        </div>
                        <ExternalLink size={14} className="sf-post-ext" />
                      </div>
                      <div className="sf-post-media" style={imgBg(post.hue)} />
                      <p className="sf-post-text">{post.text}</p>
                      <div className="sf-post-stats">
                        <span><Heart size={13} /> {fmt(post.likes)}</span>
                        <span><MessageCircle size={13} /> {fmt(post.comments)}</span>
                        {post.platform === "reddit" && <span><Repeat2 size={13} /> Share</span>}
                      </div>
                    </a>
                  );
                })}
              </div>
            </div>
          </main>

          <aside className="sf-side">
            <div className="sf-side-card">
              <button className="sf-btn-primary sf-btn-block"><Phone size={17} /> Contact business</button>
              <p className="sf-response"><Clock size={13} /> {b.responseTime}</p>
            </div>
            <div className="sf-side-card">
              <h3 className="sf-side-h">Contact info</h3>
              <a className="sf-contact" href={`tel:${b.contact.phone}`}><Phone size={16} /> <span>{b.contact.phone}</span></a>
              <a className="sf-contact" href={`https://${b.contact.website}`}><Globe size={16} /> <span>{b.contact.website}</span></a>
              <a className="sf-contact" href={`mailto:${b.contact.email}`}><Mail size={16} /> <span>{b.contact.email}</span></a>
              <div className="sf-social">
                {Object.entries(PLATFORMS).map(([key, p]) => (
                  <a key={key} href="#" aria-label={p.label} style={{ "--pc": p.color }}><p.Icon size={16} /></a>
                ))}
              </div>
            </div>
            <div className="sf-side-card">
              <h3 className="sf-side-h">Hours</h3>
              {b.hours.map((h) => (
                <div key={h.d} className="sf-hourrow"><span>{h.d}</span><span className={h.open ? "" : "sf-closed"}>{h.h}</span></div>
              ))}
            </div>
            <div className="sf-side-card">
              <h3 className="sf-side-h">Location</h3>
              <div className="sf-map"><MapPin size={22} style={{ color: "var(--accent)" }} /></div>
              <p className="sf-address">{b.location.address}</p>
            </div>
            <button className="sf-report"><Flag size={13} /> Report this listing</button>
          </aside>
        </div>
      </div>

      {lightbox !== null && (
        <div className="sf-lightbox" onClick={() => setLightbox(null)}>
          <button className="sf-lb-nav" onClick={(e) => { e.stopPropagation(); setLightbox((lightbox - 1 + b.gallery.length) % b.gallery.length); }}><ChevronLeft size={26} /></button>
          <div className="sf-lb-img" style={imgBg(b.gallery[lightbox].hue)} onClick={(e) => e.stopPropagation()}><span>{b.gallery[lightbox].label}</span></div>
          <button className="sf-lb-nav" onClick={(e) => { e.stopPropagation(); setLightbox((lightbox + 1) % b.gallery.length); }}><ChevronRight size={26} /></button>
        </div>
      )}
    </div>
  );
}

// Custom brand icons not in lucide
function TikTokIcon({ size = 16 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor"><path d="M16.6 5.82a4.28 4.28 0 0 1-1-.06 4.28 4.28 0 0 1-2.9-2.31A4.24 4.24 0 0 1 12.4 2h-3.1v13.4a2.6 2.6 0 0 1-2.6 2.5 2.6 2.6 0 1 1 .74-5.09V9.66a5.7 5.7 0 0 0-.74-.05A5.68 5.68 0 1 0 12.4 15.3V8.6a7.3 7.3 0 0 0 4.2 1.34V6.8a4.28 4.28 0 0 1-.2-.98z"/></svg>;
}
function RedditIcon({ size = 16 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor"><path d="M22 11.8a2.2 2.2 0 0 0-3.72-1.57 10.6 10.6 0 0 0-5.5-1.72l.94-4.4 3.06.65a1.56 1.56 0 1 0 .18-.9l-3.42-.72a.45.45 0 0 0-.53.34l-1.05 4.94a10.6 10.6 0 0 0-5.6 1.72A2.2 2.2 0 1 0 3 13.9a4 4 0 0 0-.05.65c0 3.3 3.85 5.98 8.6 5.98s8.6-2.68 8.6-5.98a4 4 0 0 0-.05-.64A2.2 2.2 0 0 0 22 11.8zM8.1 13.4a1.32 1.32 0 1 1 2.64 0 1.32 1.32 0 0 1-2.64 0zm7.3 3.72c-.9.9-2.6.97-3.1.97s-2.2-.07-3.1-.97a.34.34 0 0 1 .48-.48c.57.57 1.78.77 2.62.77s2.05-.2 2.62-.77a.34.34 0 0 1 .48.48zm-.23-2.4a1.32 1.32 0 1 1 0-2.64 1.32 1.32 0 0 1 0 2.64z"/></svg>;
}
function PinterestIcon({ size = 16 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12c0 4.24 2.64 7.86 6.36 9.32-.09-.79-.17-2 .03-2.87.18-.77 1.17-4.95 1.17-4.95s-.3-.6-.3-1.48c0-1.39.8-2.42 1.8-2.42.85 0 1.26.64 1.26 1.4 0 .86-.54 2.14-.82 3.33-.24 1 .5 1.81 1.48 1.81 1.78 0 3.14-1.87 3.14-4.58 0-2.39-1.72-4.07-4.17-4.07-2.84 0-4.51 2.13-4.51 4.33 0 .86.33 1.78.74 2.28.08.1.09.19.07.29l-.28 1.14c-.04.18-.15.22-.34.13-1.25-.58-2.03-2.4-2.03-3.87 0-3.15 2.29-6.04 6.6-6.04 3.46 0 6.15 2.47 6.15 5.77 0 3.44-2.17 6.21-5.18 6.21-1.01 0-1.96-.53-2.29-1.15l-.62 2.37c-.22.87-.83 1.96-1.24 2.62.94.29 1.92.44 2.95.44 5.52 0 10-4.48 10-10S17.52 2 12 2z"/></svg>;
}

function SFStyle() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
      .sf{
        --bg:#f6f7f9;--card:#ffffff;--ink:#1a1d24;--mute:#5b6270;--faint:#9aa1ad;
        --border:#e7e9ee;--border2:#eef0f4;--accent:#2563eb;--accent-soft:#eef3ff;
        --star:#f5a623;--green:#0ca678;--green-soft:#e6f7f1;
        --font:'Plus Jakarta Sans',system-ui,-apple-system,sans-serif;
        background:var(--bg);color:var(--ink);font-family:var(--font);min-height:100vh;padding-bottom:64px;-webkit-font-smoothing:antialiased;
      }
      .sf *{box-sizing:border-box}
      .sf a{text-decoration:none}
      .sf-container{max-width:1080px;margin:0 auto;padding:0 24px}

      .sf-topnav{background:var(--card);border-bottom:1px solid var(--border);position:sticky;top:0;z-index:20}
      .sf-topnav-inner{display:flex;align-items:center;justify-content:space-between;height:64px}
      .sf-logo{font-weight:800;font-size:21px;letter-spacing:-.02em;color:var(--ink)}
      .sf-logo span{color:var(--accent)}
      .sf-topnav-actions{display:flex;gap:22px;align-items:center}
      .sf-topnav-link{font-size:14px;font-weight:600;color:var(--mute)}
      .sf-topnav-link:hover{color:var(--ink)}

      .sf-crumbs{display:flex;flex-wrap:wrap;align-items:center;gap:6px;padding:18px 0 4px;font-size:13px;color:var(--faint)}
      .sf-crumbs a{color:var(--mute)}
      .sf-crumbs a:hover{color:var(--accent)}
      .sf-crumb-current{color:var(--ink);font-weight:600}

      .sf-header{background:var(--card);border:1px solid var(--border);border-radius:20px;padding:26px;margin-top:14px;display:flex;gap:22px;align-items:center;box-shadow:0 1px 3px rgba(20,24,40,.04)}
      .sf-logo-badge{width:88px;height:88px;border-radius:18px;background:linear-gradient(135deg,var(--accent),#4f7cf7);color:#fff;font-weight:800;font-size:40px;display:grid;place-items:center;flex-shrink:0}
      .sf-header-body{flex:1;min-width:0}
      .sf-title-row{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
      .sf-name{font-size:clamp(23px,3.2vw,30px);font-weight:800;letter-spacing:-.02em;margin:0}
      .sf-verified{display:inline-flex;align-items:center;gap:4px;font-size:12.5px;font-weight:700;color:var(--green);background:var(--green-soft);padding:4px 10px;border-radius:999px}
      .sf-meta{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-top:9px;color:var(--mute);font-size:14px}
      .sf-cat{color:var(--accent);font-weight:700}
      .sf-metaitem{display:inline-flex;align-items:center;gap:5px}
      .sf-dot{width:3px;height:3px;border-radius:50%;background:var(--faint)}
      .sf-rating-row{display:flex;align-items:center;gap:8px;margin-top:12px;font-size:14.5px}
      .sf-rating-row strong{font-weight:700}
      .sf-reviewlink{color:var(--mute);font-weight:500}
      .sf-reviewlink:hover{color:var(--accent)}
      .sf-header-cta{display:flex;gap:10px;align-items:center;flex-shrink:0}

      .sf-btn-primary{display:inline-flex;align-items:center;justify-content:center;gap:8px;background:var(--accent);color:#fff;font-weight:700;font-size:14.5px;font-family:inherit;border:none;border-radius:12px;padding:13px 22px;cursor:pointer;transition:background .15s,transform .1s}
      .sf-btn-primary:hover{background:#1d4fd8;transform:translateY(-1px)}
      .sf-btn-block{width:100%}
      .sf-btn-icon{display:inline-flex;align-items:center;justify-content:center;background:var(--card);border:1px solid var(--border);color:var(--mute);border-radius:12px;width:46px;height:46px;cursor:pointer}
      .sf-btn-icon:hover{color:var(--ink);border-color:var(--faint)}
      .sf-btn-outline{display:inline-flex;align-items:center;gap:8px;background:var(--card);border:1.5px solid var(--border);color:var(--ink);font-weight:600;font-size:14px;font-family:inherit;border-radius:11px;padding:11px 18px;cursor:pointer}
      .sf-btn-outline:hover{border-color:var(--accent);color:var(--accent)}

      .sf-layout{display:grid;grid-template-columns:1fr 328px;gap:24px;margin-top:20px}
      @media(max-width:880px){.sf-layout{grid-template-columns:1fr}.sf-header{flex-wrap:wrap}.sf-header-cta{width:100%}.sf-header-cta .sf-btn-primary{flex:1}}

      .sf-tabs{display:flex;gap:4px;background:var(--card);border:1px solid var(--border);border-radius:14px;padding:6px;margin-bottom:20px;overflow-x:auto}
      .sf-tab{background:none;border:none;color:var(--mute);font-size:13.5px;font-weight:600;font-family:inherit;padding:10px 15px;cursor:pointer;border-radius:9px;white-space:nowrap;transition:all .15s}
      .sf-tab:hover{color:var(--ink)}
      .sf-tab-on{background:var(--accent-soft);color:var(--accent)}

      .sf-panel-card{background:var(--card);border:1px solid var(--border);border-radius:18px;padding:26px;box-shadow:0 1px 3px rgba(20,24,40,.04)}
      .sf-fade{animation:sfIn .22s ease}
      @keyframes sfIn{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:none}}
      .sf-desc{font-size:15px;line-height:1.7;color:var(--mute);margin:0 0 26px}
      .sf-h3{display:flex;align-items:center;gap:8px;font-size:15px;font-weight:700;margin:0 0 15px}
      .sf-h3 svg{color:var(--accent)}
      .sf-h3:not(:first-child){margin-top:28px}
      .sf-badges{display:flex;flex-wrap:wrap;gap:9px}
      .sf-badge{display:inline-flex;align-items:center;gap:6px;background:var(--bg);border:1px solid var(--border);color:var(--ink);padding:8px 13px;border-radius:9px;font-size:13px;font-weight:600}
      .sf-badge svg{color:var(--green)}
      .sf-muted{color:var(--faint)}

      .sf-strip{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}
      .sf-strip-img{aspect-ratio:1;border:none;border-radius:12px;cursor:pointer;transition:transform .12s}
      .sf-strip-img:hover{transform:scale(1.03)}

      /* Services */
      .sf-svc-list{display:flex;flex-direction:column;gap:10px}
      .sf-svc{display:flex;align-items:center;gap:14px;background:var(--bg);border:1px solid var(--border2);border-radius:12px;padding:15px 18px}
      .sf-svc-body{flex:1}
      .sf-svc-body strong{font-size:14.5px}
      .sf-svc-body p{margin:4px 0 0;font-size:13px;color:var(--mute);line-height:1.5}
      .sf-svc-price{font-weight:700;font-size:14px;color:var(--accent);white-space:nowrap}

      /* Products */
      .sf-products{display:grid;grid-template-columns:1fr 1fr;gap:14px}
      @media(max-width:560px){.sf-products{grid-template-columns:1fr}}
      .sf-product{border:1px solid var(--border2);border-radius:14px;overflow:hidden;transition:box-shadow .15s}
      .sf-product:hover{box-shadow:0 4px 14px rgba(20,24,40,.08)}
      .sf-product-img{aspect-ratio:16/10}
      .sf-product-info{padding:14px;display:flex;flex-direction:column;gap:3px}
      .sf-product-info strong{font-size:14px}
      .sf-product-note{font-size:12px;color:var(--faint)}
      .sf-product-price{font-size:14px;font-weight:700;color:var(--accent);margin-top:4px}

      /* Articles */
      .sf-articles{display:flex;flex-direction:column;gap:14px}
      .sf-article{display:flex;gap:16px;border:1px solid var(--border2);border-radius:14px;overflow:hidden;transition:box-shadow .15s}
      .sf-article:hover{box-shadow:0 4px 14px rgba(20,24,40,.08)}
      .sf-article-thumb{width:130px;flex-shrink:0}
      @media(max-width:560px){.sf-article-thumb{width:96px}}
      .sf-article-body{padding:14px 16px 14px 0;flex:1}
      .sf-article-body h4{margin:0 0 6px;font-size:15px;font-weight:700;line-height:1.35;color:var(--ink)}
      .sf-article-body p{margin:0 0 8px;font-size:13px;color:var(--mute);line-height:1.5}
      .sf-article-meta{font-size:12px;color:var(--faint);font-weight:600}

      /* Videos */
      .sf-videos{display:grid;grid-template-columns:1fr 1fr;gap:16px}
      @media(max-width:560px){.sf-videos{grid-template-columns:1fr}}
      .sf-video-thumb{aspect-ratio:16/9;border-radius:12px;position:relative;display:grid;place-items:center;overflow:hidden}
      .sf-play{color:#fff;opacity:.92;filter:drop-shadow(0 2px 6px rgba(0,0,0,.3))}
      .sf-video-dur{position:absolute;bottom:8px;right:8px;background:rgba(0,0,0,.75);color:#fff;font-size:11px;font-weight:600;padding:2px 6px;border-radius:5px}
      .sf-video-info{display:flex;flex-direction:column;gap:2px;padding:10px 2px 0}
      .sf-video-info strong{font-size:14px;line-height:1.35}
      .sf-video-info .sf-muted{font-size:12.5px}

      /* Gallery */
      .sf-gallery{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
      @media(max-width:640px){.sf-gallery{grid-template-columns:repeat(2,1fr)}}
      .sf-gcard{aspect-ratio:4/3;border:none;border-radius:14px;cursor:pointer;position:relative;overflow:hidden;display:flex;align-items:flex-end;padding:12px;transition:transform .12s}
      .sf-gcard:hover{transform:scale(1.02)}
      .sf-gcard-label{font-size:12px;font-weight:600;color:#fff;text-shadow:0 1px 4px rgba(0,0,0,.4)}

      /* Reviews */
      .sf-review-top{display:flex;gap:32px;align-items:center;flex-wrap:wrap;padding-bottom:22px;border-bottom:1px solid var(--border2);margin-bottom:20px}
      .sf-review-score{display:flex;flex-direction:column;gap:6px;align-items:flex-start}
      .sf-score-num{font-size:44px;font-weight:800;line-height:1}
      .sf-review-bars{flex:1;min-width:200px;display:flex;flex-direction:column;gap:7px}
      .sf-barrow{display:flex;align-items:center;gap:8px;font-size:13px;color:var(--mute)}
      .sf-bar{flex:1;height:7px;background:var(--border2);border-radius:99px;overflow:hidden}
      .sf-bar-fill{height:100%;background:var(--star);border-radius:99px}
      .sf-barpct{width:34px;text-align:right}
      .sf-write{margin-bottom:22px}
      .sf-reviews{display:flex;flex-direction:column;gap:16px}
      .sf-review{border:1px solid var(--border2);border-radius:14px;padding:18px}
      .sf-review-head{display:flex;align-items:center;gap:12px;margin-bottom:11px}
      .sf-avatar{width:42px;height:42px;border-radius:50%;background:var(--accent-soft);color:var(--accent);font-weight:700;display:grid;place-items:center;font-size:16px}
      .sf-review-sub{display:flex;align-items:center;gap:8px;margin-top:3px;font-size:12.5px}
      .sf-review-text{margin:0;font-size:14px;line-height:1.65;color:var(--mute)}

      /* Social feed */
      .sf-social-section{background:var(--card);border:1px solid var(--border);border-radius:18px;padding:26px;margin-top:20px;box-shadow:0 1px 3px rgba(20,24,40,.04)}
      .sf-social-head{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:18px}
      .sf-social-follow{display:flex;gap:8px}
      .sf-follow-chip{width:36px;height:36px;border-radius:10px;display:grid;place-items:center;background:var(--bg);color:var(--pc);border:1px solid var(--border2);transition:all .15s}
      .sf-follow-chip:hover{background:var(--pc);color:#fff;border-color:var(--pc)}
      .sf-social-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
      @media(max-width:760px){.sf-social-grid{grid-template-columns:repeat(2,1fr)}}
      @media(max-width:520px){.sf-social-grid{grid-template-columns:1fr}}
      .sf-post{border:1px solid var(--border2);border-radius:14px;overflow:hidden;display:flex;flex-direction:column;transition:box-shadow .15s;background:var(--card)}
      .sf-post:hover{box-shadow:0 4px 14px rgba(20,24,40,.08)}
      .sf-post-head{display:flex;align-items:center;gap:9px;padding:12px 12px 10px}
      .sf-post-platform{width:26px;height:26px;border-radius:7px;display:grid;place-items:center;color:#fff;flex-shrink:0}
      .sf-post-id{flex:1;min-width:0;display:flex;flex-direction:column;line-height:1.3}
      .sf-post-id strong{font-size:12.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      .sf-post-id .sf-muted{font-size:11px}
      .sf-post-ext{color:var(--faint);flex-shrink:0}
      .sf-post-media{aspect-ratio:1;width:100%}
      .sf-post-text{margin:0;padding:11px 12px 8px;font-size:13px;line-height:1.5;color:var(--ink);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
      .sf-post-stats{display:flex;gap:14px;padding:0 12px 12px;font-size:12px;color:var(--mute);font-weight:600}
      .sf-post-stats span{display:inline-flex;align-items:center;gap:4px}

      /* Sidebar */
      .sf-side{display:flex;flex-direction:column;gap:16px}
      .sf-side-card{background:var(--card);border:1px solid var(--border);border-radius:18px;padding:20px;box-shadow:0 1px 3px rgba(20,24,40,.04)}
      .sf-response{display:flex;align-items:center;gap:6px;font-size:12.5px;color:var(--mute);margin:12px 0 0;justify-content:center}
      .sf-side-h{font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:var(--faint);margin:0 0 15px}
      .sf-contact{display:flex;align-items:center;gap:11px;color:var(--ink);font-size:14px;font-weight:600;padding:9px 0}
      .sf-contact svg{color:var(--accent);flex-shrink:0}
      .sf-contact span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      .sf-contact:hover span{color:var(--accent)}
      .sf-social{display:flex;gap:8px;margin-top:13px;padding-top:15px;border-top:1px solid var(--border2);flex-wrap:wrap}
      .sf-social a{width:38px;height:38px;border-radius:10px;background:var(--bg);color:var(--pc,var(--mute));display:grid;place-items:center;transition:all .15s}
      .sf-social a:hover{background:var(--pc,var(--accent-soft));color:#fff}
      .sf-hourrow{display:flex;justify-content:space-between;font-size:13.5px;padding:7px 0;color:var(--mute)}
      .sf-hourrow span:first-child{font-weight:600;color:var(--ink)}
      .sf-closed{color:var(--faint)}
      .sf-map{height:140px;background:linear-gradient(135deg,#eef1f6,#e4e8f0);border-radius:12px;display:grid;place-items:center;margin-bottom:13px}
      .sf-address{font-size:13.5px;color:var(--mute);margin:0;line-height:1.55}
      .sf-report{display:inline-flex;align-items:center;gap:6px;background:none;border:none;color:var(--faint);font-size:12.5px;font-family:inherit;cursor:pointer;padding:4px;align-self:center}
      .sf-report:hover{color:var(--mute)}

      .sf-lightbox{position:fixed;inset:0;z-index:50;background:rgba(15,18,28,.85);display:flex;align-items:center;justify-content:center;gap:14px;padding:24px}
      .sf-lb-img{width:min(760px,78vw);aspect-ratio:4/3;border-radius:18px;display:flex;align-items:flex-end;padding:22px}
      .sf-lb-img span{color:#fff;font-weight:600;text-shadow:0 1px 6px rgba(0,0,0,.5)}
      .sf-lb-nav{background:rgba(255,255,255,.14);border:none;color:#fff;width:50px;height:50px;border-radius:50%;cursor:pointer;display:grid;place-items:center;flex-shrink:0}
      .sf-lb-nav:hover{background:rgba(255,255,255,.24)}
    `}</style>
  );
}
